"""
collector/log_collector.py
============================
Top-level orchestrator for log collection.

Picks the correct platform-specific collector (Linux or Windows) at
runtime, polls it on a fixed interval, and persists every normalized
event into the ``logs`` table via :class:`DatabaseManager`.

This module is what ``app.py`` starts in a background thread.
"""

from __future__ import annotations

import platform
import time
from typing import Optional

from collector.base_collector import BaseCollector
from collector.linux_collector import LinuxCollector
from collector.windows_collector import WindowsCollector
from config import Config
from database.db_manager import DatabaseManager
from utils.logger import get_logger

logger = get_logger(__name__)


def build_platform_collector() -> BaseCollector:
    """
    Instantiate the appropriate collector for the current operating system.

    Returns:
        A LinuxCollector on Linux, a WindowsCollector on Windows.
        Falls back to LinuxCollector (a safe no-op if log files are
        absent) on any other platform.
    """
    system = platform.system()
    if system == "Windows":
        logger.info("Detected Windows platform; using WindowsCollector.")
        return WindowsCollector()

    if system == "Linux":
        logger.info("Detected Linux platform; using LinuxCollector.")
        return LinuxCollector()

    logger.warning(
        "Unrecognized platform '%s'; defaulting to LinuxCollector "
        "(no logs will be collected unless auth.log/syslog exist).",
        system,
    )
    return LinuxCollector()


class LogCollectionService:
    """Runs a polling loop that collects logs and stores them in SQLite."""

    def __init__(
        self,
        db_manager: DatabaseManager,
        collector: Optional[BaseCollector] = None,
        polling_interval: Optional[int] = None,
    ) -> None:
        self.db_manager = db_manager
        self.collector = collector or build_platform_collector()
        self.polling_interval = polling_interval or Config.POLLING_INTERVAL_SECONDS
        self._running = False

    def run_once(self) -> int:
        """
        Perform a single collection pass.

        Returns:
            The number of new log records inserted into the database.
        """
        try:
            new_logs = self.collector.collect()
        except Exception:  # pylint: disable=broad-except
            logger.exception("Collector raised an unexpected error during collect().")
            return 0

        for log in new_logs:
            self.db_manager.insert_log(
                timestamp=log.timestamp,
                hostname=log.hostname,
                event_type=log.event_type,
                message=log.message,
                username=log.username,
                source_ip=log.source_ip,
                severity=log.severity,
            )

        if new_logs:
            logger.info("Collected and stored %d new log record(s).", len(new_logs))

        return len(new_logs)

    def run_forever(self) -> None:
        """Run the collection loop until ``stop()`` is called."""
        self._running = True
        logger.info(
            "Log collection service started (interval=%ss).", self.polling_interval
        )
        while self._running:
            self.run_once()
            time.sleep(self.polling_interval)

    def stop(self) -> None:
        """Signal the polling loop to stop after its current iteration."""
        self._running = False
        logger.info("Log collection service stop requested.")
