"""
collector/linux_collector.py
=============================
Collects and normalizes log events from Linux system logs.

Log source resolution order (automatic, no configuration required):

1. ``/var/log/auth.log`` (Debian/Ubuntu)
2. ``/var/log/secure``   (RHEL/CentOS)
3. systemd journal via ``journalctl`` (modern Kali/Ubuntu with journald)
4. ``sample_logs/auth.log`` demo file (always available as last resort)

Similarly for syslog:
1. ``/var/log/syslog``
2. ``/var/log/messages``
3. ``sample_logs/syslog``

Only lines appended since the last poll are processed (via
``BaseCollector._tail_new_lines``), so this collector is safe to call
repeatedly in a polling loop.
"""

from __future__ import annotations

import datetime as _dt
import os
import re
import shutil
import subprocess
from typing import List, Optional

from collector.base_collector import BaseCollector
from config import Config
from utils.json_normalizer import NormalizedLog, build_normalized_log, now_iso
from utils.logger import get_logger

logger = get_logger(__name__)

# --- Regex patterns for common Linux auth.log / secure entries -----------

# Example: "Jan 10 03:14:15 web01 sshd[1234]: Failed password for invalid
#           user admin from 203.0.113.5 port 51514 ssh2"
_RE_FAILED_PASSWORD = re.compile(
    r"Failed password for (invalid user )?(?P<username>\S+) "
    r"from (?P<source_ip>[\d\.:a-fA-F]+) port (?P<port>\d+)"
)

# Example: "Jan 10 03:15:02 web01 sshd[1234]: Accepted password for root
#           from 203.0.113.5 port 51520 ssh2"
_RE_ACCEPTED_PASSWORD = re.compile(
    r"Accepted (password|publickey) for (?P<username>\S+) "
    r"from (?P<source_ip>[\d\.:a-fA-F]+) port (?P<port>\d+)"
)

# Example: "Jan 10 03:14:15 web01 sudo: pam_unix(sudo:auth): authentication
#           failure; ... user=alice"
_RE_SUDO_FAILURE = re.compile(
    r"sudo:.*authentication failure.*user=(?P<username>\S+)"
)

# Standard syslog line prefix: "Mon DD HH:MM:SS hostname process[pid]: msg"
_RE_SYSLOG_PREFIX = re.compile(
    r"^(?P<month>\w{3})\s+(?P<day>\d{1,2})\s+(?P<time>\d{2}:\d{2}:\d{2})\s+"
    r"(?P<host>\S+)\s+(?P<process>[\w\-/\.]+)(\[\d+\])?:\s*(?P<msg>.*)$"
)


def _journalctl_available() -> bool:
    """Check if journalctl is available on this system."""
    return shutil.which("journalctl") is not None


class LinuxCollector(BaseCollector):
    """Collects normalized log events from Linux auth.log, syslog, or journald."""

    def __init__(self) -> None:
        super().__init__()
        self.hostname: str = self.get_hostname()

        # Resolve the best available log sources
        self.auth_log_path: Optional[str] = self._resolve_auth_source()
        self.syslog_path: Optional[str] = self._resolve_syslog_source()

        # Track whether journald is used as primary auth source
        self._use_journald_auth: bool = False
        self._journald_last_cursor: Optional[str] = None

        if self.auth_log_path:
            logger.info("Auth log source: %s", self.auth_log_path)
        elif _journalctl_available():
            self._use_journald_auth = True
            logger.info("Auth log source: systemd journal (journalctl)")
        else:
            logger.warning(
                "No auth log source found. Neither file-based logs, "
                "journalctl, nor demo files are available."
            )

        if self.syslog_path:
            logger.info("Syslog source: %s", self.syslog_path)
        else:
            logger.warning("No syslog source found.")

    def _resolve_auth_source(self) -> Optional[str]:
        """
        Resolve auth log file using the fallback chain:
        1. System auth log files (auth.log, secure)
        2. Demo file (sample_logs/auth.log) — always available
        """
        # Check if demo mode is forced
        if Config.DEMO_MODE:
            demo_path = str(Config.SAMPLE_LOGS_DIR / "auth.log")
            self._ensure_demo_file(demo_path)
            return demo_path

        # Try system log files first
        system_path = self._resolve_path(Config.LINUX_AUTH_LOG_PATHS)
        if system_path:
            return system_path

        # journalctl is checked separately (not file-based)
        # If journalctl is available, return None here and use _use_journald_auth
        if _journalctl_available():
            return None

        # Fall back to demo file
        demo_path = str(Config.SAMPLE_LOGS_DIR / "auth.log")
        if os.path.isfile(demo_path):
            logger.info("Falling back to demo auth log: %s", demo_path)
            return demo_path

        return None

    def _resolve_syslog_source(self) -> Optional[str]:
        """
        Resolve syslog file using the fallback chain:
        1. System syslog files (syslog, messages)
        2. Demo file (sample_logs/syslog)
        """
        if Config.DEMO_MODE:
            demo_path = str(Config.SAMPLE_LOGS_DIR / "syslog")
            self._ensure_demo_file(demo_path)
            return demo_path

        system_path = self._resolve_path(Config.LINUX_SYSLOG_PATHS)
        if system_path:
            return system_path

        demo_path = str(Config.SAMPLE_LOGS_DIR / "syslog")
        if os.path.isfile(demo_path):
            logger.info("Falling back to demo syslog: %s", demo_path)
            return demo_path

        return None

    @staticmethod
    def _ensure_demo_file(path: str) -> None:
        """Create the demo file if it doesn't exist."""
        from pathlib import Path

        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.touch(exist_ok=True)

    @staticmethod
    def _resolve_path(candidates: List[str]) -> Optional[str]:
        """Return the first existing, readable path from a list of candidates."""
        for candidate in candidates:
            if os.path.isfile(candidate) and os.access(candidate, os.R_OK):
                return candidate
        return None

    def _collect_journald_auth(self) -> List[str]:
        """
        Collect auth-related log lines from systemd journal.

        Uses a cursor to track the last read position, ensuring only
        new entries are returned on each poll.
        """
        if not self._use_journald_auth:
            return []

        try:
            cmd = [
                "journalctl",
                "--no-pager",
                "-o", "short",
                "-u", "ssh",
                "-u", "sshd",
                "-t", "sshd",
                "-t", "sudo",
                "--priority", "0..6",
            ]

            if self._journald_last_cursor:
                cmd.extend(["--after-cursor", self._journald_last_cursor])
            else:
                # On first run, get recent entries (last 5 minutes)
                cmd.extend(["--since", "5 min ago"])

            # Add cursor output
            cmd.append("--show-cursor")

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=10,
                encoding="utf-8",
                errors="replace",
            )

            if result.returncode != 0:
                logger.debug("journalctl returned code %d: %s", result.returncode, result.stderr)
                return []

            lines: List[str] = []
            for line in result.stdout.strip().splitlines():
                stripped = line.strip()
                if stripped.startswith("-- cursor:"):
                    # Extract cursor for next poll
                    self._journald_last_cursor = stripped.split(":", 1)[1].strip()
                elif stripped:
                    lines.append(stripped)

            return lines

        except subprocess.TimeoutExpired:
            logger.warning("journalctl timed out.")
            return []
        except FileNotFoundError:
            logger.warning("journalctl not found, disabling journald collection.")
            self._use_journald_auth = False
            return []
        except Exception:  # pylint: disable=broad-except
            logger.exception("Error reading from journalctl.")
            return []

    def collect(self) -> List[NormalizedLog]:
        """Collect new normalized events from auth.log, journald, and syslog."""
        results: List[NormalizedLog] = []

        # Collect from file-based auth log
        if self.auth_log_path:
            for line in self._tail_new_lines(self.auth_log_path):
                normalized = self._parse_auth_line(line)
                if normalized:
                    results.append(normalized)

        # Collect from journald (if no file-based auth log)
        if self._use_journald_auth:
            for line in self._collect_journald_auth():
                normalized = self._parse_auth_line(line)
                if normalized:
                    results.append(normalized)

        # Collect from syslog
        if self.syslog_path:
            for line in self._tail_new_lines(self.syslog_path):
                normalized = self._parse_syslog_line(line)
                if normalized:
                    results.append(normalized)

        return results

    def _parse_timestamp(self, month: str, day: str, time_str: str) -> str:
        """Convert 'Mon DD HH:MM:SS' syslog timestamp (no year) to ISO-8601 UTC.

        Classic syslog/auth.log timestamps carry no timezone and are written
        in the system's *local* time, not UTC. Detectors compare timestamps
        against ``datetime.now(timezone.utc)``-based windows, so mislabeling
        a local timestamp as UTC (rather than converting it) would silently
        shift every parsed event by the local UTC offset -- on a UTC-4
        system that's enough to push a brute-force burst entirely outside
        the default 120s detection window and make FailedLoginDetector never
        fire. ``astimezone()`` on a naive datetime assumes the system's
        local timezone, which is exactly the assumption syslog makes when
        writing these lines.
        """
        try:
            current_year = _dt.datetime.now().year
            naive_local = _dt.datetime.strptime(
                f"{current_year} {month} {day} {time_str}", "%Y %b %d %H:%M:%S"
            )
            local_aware = naive_local.astimezone()
            return local_aware.astimezone(_dt.timezone.utc).isoformat()
        except ValueError:
            return now_iso()

    def _parse_auth_line(self, line: str) -> Optional[NormalizedLog]:
        """Parse a single auth.log / secure line into a NormalizedLog, if relevant."""
        prefix_match = _RE_SYSLOG_PREFIX.match(line)
        timestamp = now_iso()
        body = line
        if prefix_match:
            timestamp = self._parse_timestamp(
                prefix_match.group("month"),
                prefix_match.group("day"),
                prefix_match.group("time"),
            )
            body = prefix_match.group("msg")

        failed_match = _RE_FAILED_PASSWORD.search(body)
        if failed_match:
            return build_normalized_log(
                hostname=self.hostname,
                event_type="failed_login",
                message=line,
                username=failed_match.group("username"),
                source_ip=failed_match.group("source_ip"),
                severity="medium",
                timestamp=timestamp,
            )

        accepted_match = _RE_ACCEPTED_PASSWORD.search(body)
        if accepted_match:
            return build_normalized_log(
                hostname=self.hostname,
                event_type="accepted_login",
                message=line,
                username=accepted_match.group("username"),
                source_ip=accepted_match.group("source_ip"),
                severity="info",
                timestamp=timestamp,
            )

        sudo_match = _RE_SUDO_FAILURE.search(body)
        if sudo_match:
            return build_normalized_log(
                hostname=self.hostname,
                event_type="failed_login",
                message=line,
                username=sudo_match.group("username"),
                source_ip=None,
                severity="medium",
                timestamp=timestamp,
            )

        return None

    def _parse_syslog_line(self, line: str) -> Optional[NormalizedLog]:
        """Parse a generic syslog line into a NormalizedLog with event_type='generic'."""
        prefix_match = _RE_SYSLOG_PREFIX.match(line)
        if not prefix_match:
            return None

        timestamp = self._parse_timestamp(
            prefix_match.group("month"), prefix_match.group("day"), prefix_match.group("time")
        )
        return build_normalized_log(
            hostname=prefix_match.group("host") or self.hostname,
            event_type="generic",
            message=line,
            username=None,
            source_ip=None,
            severity="info",
            timestamp=timestamp,
        )
