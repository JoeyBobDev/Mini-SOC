"""Collector package: OS log collection and normalization."""
