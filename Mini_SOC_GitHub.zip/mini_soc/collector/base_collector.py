"""
collector/base_collector.py
============================
Abstract base class shared by all OS-specific log collectors.

Concrete collectors (LinuxCollector, WindowsCollector) implement
``collect()`` which returns a list of :class:`NormalizedLog` objects
representing *new* events found since the previous call. The base
class provides a reusable "tail a text file from the last read
position" helper so subclasses do not duplicate file-offset tracking
logic.
"""

from __future__ import annotations

import os
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional

from utils.json_normalizer import NormalizedLog
from utils.logger import get_logger

logger = get_logger(__name__)


class BaseCollector(ABC):
    """Common interface and utilities for all platform log collectors."""

    def __init__(self) -> None:
        # Tracks byte offset already read for each tailed file so repeated
        # polling only processes newly appended lines.
        self._file_offsets: dict[str, int] = {}

    @abstractmethod
    def collect(self) -> list[NormalizedLog]:
        """
        Collect and normalize new log events since the last call.

        Returns:
            A list of NormalizedLog instances (possibly empty).
        """
        raise NotImplementedError

    def _tail_new_lines(self, file_path: str) -> list[str]:
        """
        Read only the lines appended to `file_path` since the last call.

        Handles log rotation gracefully: if the file shrinks (rotated),
        the offset is reset to the start of the file.

        Args:
            file_path: Absolute path of the log file to tail.

        Returns:
            List of new, non-empty lines (without trailing newlines).
        """
        path = Path(file_path)
        if not path.exists():
            logger.debug("Log file not found, skipping: %s", file_path)
            return []

        try:
            file_size = path.stat().st_size
            # On the very first read of a file we start from offset 0 so
            # existing log history is ingested immediately (useful for a
            # monitoring tool you just started). Subsequent calls resume
            # from wherever the last read left off.
            last_offset = self._file_offsets.get(file_path, 0)

            # If the file shrank, it was likely rotated/truncated.
            if file_size < last_offset:
                logger.info("Detected log rotation for %s, resetting offset.", file_path)
                last_offset = 0

            new_lines: list[str] = []
            with open(file_path, "r", encoding="utf-8", errors="replace") as handle:
                handle.seek(last_offset)
                for raw_line in handle:
                    stripped = raw_line.strip()
                    if stripped:
                        new_lines.append(stripped)
                self._file_offsets[file_path] = handle.tell()

            return new_lines
        except (OSError, PermissionError) as exc:
            logger.warning("Could not read log file %s: %s", file_path, exc)
            return []

    @staticmethod
    def get_hostname() -> str:
        """Return the local machine's hostname."""
        return os.uname().nodename if hasattr(os, "uname") else os.environ.get(
            "COMPUTERNAME", "unknown-host"
        )

    def reset_offset(self, file_path: str, offset: Optional[int] = None) -> None:
        """Manually reset (or clear) the tracked read offset for a file."""
        if offset is None:
            self._file_offsets.pop(file_path, None)
        else:
            self._file_offsets[file_path] = offset
