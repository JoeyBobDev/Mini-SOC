"""
collector/windows_collector.py
================================
Collects and normalizes log events from the Windows Event Logs.

Relies on ``pywin32`` (win32evtlog), which is only available on Windows.
On any other platform, importing this module still succeeds but
``WindowsCollector.collect()`` will log a warning and return an empty
list, so the rest of the application keeps working cross-platform.

Relevant Windows Security Event IDs:
    4624 - An account was successfully logged on
    4625 - An account failed to log on
    4740 - A user account was locked out

System Event Log events of interest:
    General system events are captured as generic logs.
"""

from __future__ import annotations

from typing import Any, List, Optional

from collector.base_collector import BaseCollector
from config import Config
from utils.json_normalizer import NormalizedLog, build_normalized_log, now_iso
from utils.logger import get_logger

logger = get_logger(__name__)

try:
    import win32evtlog  # type: ignore
    import win32evtlogutil  # type: ignore
    import win32security  # type: ignore

    _PYWIN32_AVAILABLE = True
except ImportError:
    _PYWIN32_AVAILABLE = False

# Windows Security Event IDs of interest.
_EVENT_ID_SUCCESSFUL_LOGON = 4624
_EVENT_ID_FAILED_LOGON = 4625
_EVENT_ID_ACCOUNT_LOCKOUT = 4740

_SECURITY_EVENT_IDS = {
    _EVENT_ID_SUCCESSFUL_LOGON,
    _EVENT_ID_FAILED_LOGON,
    _EVENT_ID_ACCOUNT_LOCKOUT,
}


class WindowsCollector(BaseCollector):
    """Collects normalized log events from the Windows Event Logs."""

    def __init__(self) -> None:
        super().__init__()
        self.hostname: str = self.get_hostname()
        self.channels: List[str] = Config.WINDOWS_EVENT_LOG_CHANNELS
        self._last_record_numbers: dict[str, Optional[int]] = {
            ch: None for ch in self.channels
        }

        if not _PYWIN32_AVAILABLE:
            logger.warning(
                "pywin32 is not available; WindowsCollector will not collect "
                "any events on this platform. Install pywin32 on a Windows "
                "host to enable this collector."
            )

    def collect(self) -> List[NormalizedLog]:
        """Collect new normalized events from all configured Windows event log channels."""
        if not _PYWIN32_AVAILABLE:
            return []

        results: List[NormalizedLog] = []

        for channel in self.channels:
            try:
                channel_results = self._collect_channel(channel)
                results.extend(channel_results)
            except Exception:  # pylint: disable=broad-except
                logger.exception("Failed to read Windows '%s' event log.", channel)

        # Sort oldest-first across all channels
        results.sort(key=lambda r: r.timestamp)
        return results

    def _collect_channel(self, channel: str) -> List[NormalizedLog]:
        """Collect events from a single Windows Event Log channel."""
        results: List[NormalizedLog] = []

        try:
            handle = win32evtlog.OpenEventLog(None, channel)
            flags = (
                win32evtlog.EVENTLOG_BACKWARDS_READ
                | win32evtlog.EVENTLOG_SEQUENTIAL_READ
            )
            events = win32evtlog.ReadEventLog(handle, flags, 0)

            last_record = self._last_record_numbers.get(channel)

            for event in events:
                record_number = event.RecordNumber
                # Stop once we reach events we've already processed.
                if last_record is not None and record_number <= last_record:
                    break

                normalized = self._parse_event(event, channel)
                if normalized:
                    results.append(normalized)

            if events:
                self._last_record_numbers[channel] = events[0].RecordNumber

            win32evtlog.CloseEventLog(handle)
        except Exception:  # pylint: disable=broad-except
            logger.exception("Failed to read Windows '%s' event log.", channel)

        # Reverse so oldest-first
        results.reverse()
        return results

    def _parse_event(self, event: Any, channel: str) -> Optional[NormalizedLog]:
        """Convert a single pywin32 event record into a NormalizedLog."""
        event_id = event.EventID & 0xFFFF  # mask off qualifier bits

        # For Security channel, only process known event IDs
        if channel == "Security" and event_id not in _SECURITY_EVENT_IDS:
            return None

        try:
            inserts: List[str] = list(event.StringInserts or [])
        except Exception:  # pylint: disable=broad-except
            inserts = []

        timestamp = now_iso()
        try:
            timestamp = event.TimeGenerated.isoformat()
        except Exception:  # pylint: disable=broad-except
            pass

        # Handle Security channel events
        if channel == "Security":
            return self._parse_security_event(event_id, inserts, timestamp)

        # Handle System channel events as generic logs
        message = f"[{channel}] EventID={event_id}"
        if inserts:
            message += " | " + " | ".join(inserts[:5])

        return build_normalized_log(
            hostname=self.hostname,
            event_type="generic",
            message=message,
            username=None,
            source_ip=None,
            severity="info",
            timestamp=timestamp,
        )

    def _parse_security_event(
        self,
        event_id: int,
        inserts: List[str],
        timestamp: str,
    ) -> Optional[NormalizedLog]:
        """Parse a Windows Security event into a NormalizedLog."""
        # Field layout varies by Windows version; we defensively pull the
        # most common positions used in 4624/4625/4740 events.
        username = inserts[5] if len(inserts) > 5 else None
        source_ip = inserts[19] if len(inserts) > 19 else None
        message = (
            f"EventID={event_id} " + " | ".join(inserts)
            if inserts
            else f"EventID={event_id}"
        )

        if event_id == _EVENT_ID_FAILED_LOGON:
            return build_normalized_log(
                hostname=self.hostname,
                event_type="failed_login",
                message=message,
                username=username,
                source_ip=source_ip,
                severity="medium",
                timestamp=timestamp,
            )

        if event_id == _EVENT_ID_ACCOUNT_LOCKOUT:
            # 4740: account lockout — username is typically in inserts[0]
            lockout_user = inserts[0] if inserts else username
            return build_normalized_log(
                hostname=self.hostname,
                event_type="account_lockout",
                message=message,
                username=lockout_user,
                source_ip=source_ip,
                severity="high",
                timestamp=timestamp,
            )

        if event_id == _EVENT_ID_SUCCESSFUL_LOGON:
            return build_normalized_log(
                hostname=self.hostname,
                event_type="accepted_login",
                message=message,
                username=username,
                source_ip=source_ip,
                severity="info",
                timestamp=timestamp,
            )

        return None
