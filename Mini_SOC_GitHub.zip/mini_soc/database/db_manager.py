"""
database/db_manager.py
=======================
Thread-safe SQLite data-access layer for Mini SOC.

The collector, detectors, and dashboard all run in different threads
(the collector/detectors run as background polling loops while Flask
serves requests). ``DatabaseManager`` opens a short-lived connection
per operation and enables WAL mode so reads and writes from multiple
threads do not block each other or corrupt the database.
"""

from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from typing import Any, Iterator, List, Optional

from config import Config
from database.models import ALL_SCHEMA_STATEMENTS
from utils.logger import get_logger

logger = get_logger(__name__)


class DatabaseManager:
    """Encapsulates all SQLite access for the logs/alerts/processes tables."""

    def __init__(self, db_path: Optional[str] = None) -> None:
        """
        Args:
            db_path: Path to the SQLite file. Defaults to Config.DATABASE_PATH.
        """
        self.db_path: str = db_path or Config.DATABASE_PATH
        self._lock = threading.Lock()
        Config.ensure_directories()
        self._initialize_schema()

    # ------------------------------------------------------------------
    # Connection handling
    # ------------------------------------------------------------------
    @contextmanager
    def _get_connection(self) -> Iterator[sqlite3.Connection]:
        """Yield a SQLite connection configured for concurrent access."""
        conn = sqlite3.connect(self.db_path, timeout=10)
        conn.row_factory = sqlite3.Row
        try:
            conn.execute("PRAGMA journal_mode=WAL;")
            conn.execute("PRAGMA foreign_keys=ON;")
            yield conn
            conn.commit()
        except sqlite3.Error:
            conn.rollback()
            logger.exception("Database error occurred; transaction rolled back.")
            raise
        finally:
            conn.close()

    def _initialize_schema(self) -> None:
        """Create tables/indexes if they do not already exist."""
        with self._lock, self._get_connection() as conn:
            for statement in ALL_SCHEMA_STATEMENTS:
                conn.execute(statement)
        logger.info("Database schema initialized at %s", self.db_path)

    # ------------------------------------------------------------------
    # Logs
    # ------------------------------------------------------------------
    def insert_log(
        self,
        timestamp: str,
        hostname: str,
        event_type: str,
        message: str,
        username: Optional[str] = None,
        source_ip: Optional[str] = None,
        severity: str = "info",
    ) -> int:
        """Insert a normalized log record and return its new row id."""
        with self._lock, self._get_connection() as conn:
            cursor = conn.execute(
                """
                INSERT INTO logs
                    (timestamp, hostname, event_type, username,
                     source_ip, message, severity)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (timestamp, hostname, event_type, username, source_ip, message, severity),
            )
            log_id = int(cursor.lastrowid)

        # Also record in the dedicated failed_logins table
        if event_type == "failed_login":
            self.insert_failed_login(
                timestamp=timestamp,
                hostname=hostname,
                username=username,
                source_ip=source_ip,
                message=message,
                log_id=log_id,
            )

        return log_id

    def get_recent_logs(self, limit: int = 50) -> List[dict[str, Any]]:
        """Return the most recent `limit` logs, newest first."""
        with self._lock, self._get_connection() as conn:
            rows = conn.execute(
                "SELECT * FROM logs ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
            return [dict(row) for row in rows]

    def get_logs_by_event_type(
        self, event_type: str, since_iso: Optional[str] = None
    ) -> List[dict[str, Any]]:
        """Return logs of a given event_type, optionally since a timestamp."""
        with self._lock, self._get_connection() as conn:
            if since_iso:
                rows = conn.execute(
                    "SELECT * FROM logs WHERE event_type = ? AND timestamp >= ? "
                    "ORDER BY timestamp ASC",
                    (event_type, since_iso),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM logs WHERE event_type = ? ORDER BY timestamp ASC",
                    (event_type,),
                ).fetchall()
            return [dict(row) for row in rows]

    def count_logs(self) -> int:
        """Return the total number of stored log records."""
        with self._lock, self._get_connection() as conn:
            row = conn.execute("SELECT COUNT(*) AS c FROM logs").fetchone()
            return int(row["c"])

    # ------------------------------------------------------------------
    # Alerts
    # ------------------------------------------------------------------
    def insert_alert(
        self,
        timestamp: str,
        alert_type: str,
        description: str,
        severity: str = "medium",
        source_ip: Optional[str] = None,
        username: Optional[str] = None,
        hostname: Optional[str] = None,
        details: Optional[dict[str, Any]] = None,
    ) -> int:
        """Insert an alert record and return its new row id."""
        details_json = json.dumps(details) if details else None
        with self._lock, self._get_connection() as conn:
            cursor = conn.execute(
                """
                INSERT INTO alerts
                    (timestamp, alert_type, severity, source_ip,
                     username, hostname, description, details)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    timestamp,
                    alert_type,
                    severity,
                    source_ip,
                    username,
                    hostname,
                    description,
                    details_json,
                ),
            )
            return int(cursor.lastrowid)

    def get_recent_alerts(self, limit: int = 50) -> List[dict[str, Any]]:
        """Return the most recent `limit` alerts, newest first."""
        with self._lock, self._get_connection() as conn:
            rows = conn.execute(
                "SELECT * FROM alerts ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
            return [dict(row) for row in rows]

    def count_alerts_by_type(self, alert_type: str) -> int:
        """Return the number of alerts recorded for a given alert_type."""
        with self._lock, self._get_connection() as conn:
            row = conn.execute(
                "SELECT COUNT(*) AS c FROM alerts WHERE alert_type = ?",
                (alert_type,),
            ).fetchone()
            return int(row["c"])

    def alert_exists_recently(
        self, alert_type: str, source_ip: Optional[str], since_iso: str
    ) -> bool:
        """
        Check whether a matching alert was already raised since `since_iso`.

        Used by detectors to avoid spamming duplicate alerts for the same
        ongoing condition (e.g. re-alerting every poll cycle for the same
        brute-force attempt).
        """
        with self._lock, self._get_connection() as conn:
            if source_ip is not None:
                row = conn.execute(
                    """
                    SELECT COUNT(*) AS c FROM alerts
                    WHERE alert_type = ? AND source_ip = ? AND timestamp >= ?
                    """,
                    (alert_type, source_ip, since_iso),
                ).fetchone()
            else:
                row = conn.execute(
                    """
                    SELECT COUNT(*) AS c FROM alerts
                    WHERE alert_type = ? AND source_ip IS NULL AND timestamp >= ?
                    """,
                    (alert_type, since_iso),
                ).fetchone()
            return int(row["c"]) > 0

    # ------------------------------------------------------------------
    # Processes
    # ------------------------------------------------------------------
    def insert_process(
        self,
        timestamp: str,
        hostname: str,
        pid: int,
        process_name: str,
        username: Optional[str] = None,
        command_line: Optional[str] = None,
        is_suspicious: bool = False,
        matched_rule: Optional[str] = None,
    ) -> int:
        """Insert a process snapshot record and return its new row id."""
        with self._lock, self._get_connection() as conn:
            cursor = conn.execute(
                """
                INSERT INTO processes
                    (timestamp, hostname, pid, process_name, username,
                     command_line, is_suspicious, matched_rule)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    timestamp,
                    hostname,
                    pid,
                    process_name,
                    username,
                    command_line,
                    int(is_suspicious),
                    matched_rule,
                ),
            )
            return int(cursor.lastrowid)

    def get_recent_suspicious_processes(self, limit: int = 50) -> List[dict[str, Any]]:
        """Return the most recent flagged (suspicious) processes."""
        with self._lock, self._get_connection() as conn:
            rows = conn.execute(
                "SELECT * FROM processes WHERE is_suspicious = 1 "
                "ORDER BY id DESC LIMIT ?",
                (limit,),
            ).fetchall()
            return [dict(row) for row in rows]

    def count_suspicious_processes(self) -> int:
        """Return the total number of flagged suspicious process records."""
        with self._lock, self._get_connection() as conn:
            row = conn.execute(
                "SELECT COUNT(*) AS c FROM processes WHERE is_suspicious = 1"
            ).fetchone()
            return int(row["c"])

    # ------------------------------------------------------------------
    # Failed Logins (dedicated table)
    # ------------------------------------------------------------------
    def insert_failed_login(
        self,
        timestamp: str,
        hostname: Optional[str] = None,
        username: Optional[str] = None,
        source_ip: Optional[str] = None,
        message: Optional[str] = None,
        log_id: Optional[int] = None,
    ) -> Optional[int]:
        """
        Insert a failed login record. Silently skips duplicates
        (same timestamp + username + source_ip).

        Returns:
            The new row id, or None if it was a duplicate.
        """
        try:
            with self._lock, self._get_connection() as conn:
                cursor = conn.execute(
                    """
                    INSERT OR IGNORE INTO failed_logins
                        (timestamp, hostname, username, source_ip, message, log_id)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (timestamp, hostname, username, source_ip, message, log_id),
                )
                return int(cursor.lastrowid) if cursor.lastrowid else None
        except Exception:  # pylint: disable=broad-except
            logger.debug("Duplicate or error inserting failed_login record.")
            return None

    def get_recent_failed_logins(self, limit: int = 50) -> List[dict[str, Any]]:
        """Return the most recent failed login records."""
        with self._lock, self._get_connection() as conn:
            rows = conn.execute(
                "SELECT * FROM failed_logins ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
            return [dict(row) for row in rows]

    # ------------------------------------------------------------------
    # Port Scans (dedicated table)
    # ------------------------------------------------------------------
    def insert_port_scan(
        self,
        timestamp: str,
        source_ip: str,
        ports_scanned: Optional[str] = None,
        port_count: int = 0,
        hostname: Optional[str] = None,
        alert_id: Optional[int] = None,
    ) -> int:
        """Insert a port scan detection record and return its new row id."""
        with self._lock, self._get_connection() as conn:
            cursor = conn.execute(
                """
                INSERT INTO port_scans
                    (timestamp, hostname, source_ip, ports_scanned,
                     port_count, alert_id)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (timestamp, hostname, source_ip, ports_scanned, port_count, alert_id),
            )
            return int(cursor.lastrowid)

    def get_recent_port_scans(self, limit: int = 50) -> List[dict[str, Any]]:
        """Return the most recent port scan records."""
        with self._lock, self._get_connection() as conn:
            rows = conn.execute(
                "SELECT * FROM port_scans ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
            return [dict(row) for row in rows]

    # ------------------------------------------------------------------
    # Dashboard statistics
    # ------------------------------------------------------------------
    def get_statistics(self) -> dict[str, int]:
        """Return aggregate counters used by the dashboard's stat cards."""
        with self._lock, self._get_connection() as conn:
            total_logs = conn.execute("SELECT COUNT(*) AS c FROM logs").fetchone()["c"]
            failed_login_alerts = conn.execute(
                "SELECT COUNT(*) AS c FROM alerts WHERE alert_type = 'failed_login'"
            ).fetchone()["c"]
            port_scan_alerts = conn.execute(
                "SELECT COUNT(*) AS c FROM alerts WHERE alert_type = 'port_scan'"
            ).fetchone()["c"]
            suspicious_processes = conn.execute(
                "SELECT COUNT(*) AS c FROM processes WHERE is_suspicious = 1"
            ).fetchone()["c"]
            total_alerts = conn.execute("SELECT COUNT(*) AS c FROM alerts").fetchone()["c"]

        return {
            "total_logs": int(total_logs),
            "failed_login_alerts": int(failed_login_alerts),
            "port_scan_alerts": int(port_scan_alerts),
            "suspicious_processes": int(suspicious_processes),
            "total_alerts": int(total_alerts),
        }
