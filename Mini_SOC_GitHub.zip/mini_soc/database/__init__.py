"""Database package: SQLite schema definitions and data-access layer."""
