"""
database/models.py
===================
SQL schema definitions for the Mini SOC SQLite database.

Five tables are defined:

1. logs               - normalized log events collected from the OS
2. alerts             - alerts raised by the detectors
3. processes          - snapshots of running processes (flagged or not)
4. failed_logins      - individual failed login event records
5. port_scans         - individual port scan detection records

Keeping the raw DDL in one place makes the schema easy to review and
version without digging through the data-access code.
"""

CREATE_LOGS_TABLE = """
CREATE TABLE IF NOT EXISTS logs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp   TEXT NOT NULL,
    hostname    TEXT NOT NULL,
    event_type  TEXT NOT NULL,
    username    TEXT,
    source_ip   TEXT,
    message     TEXT NOT NULL,
    severity    TEXT NOT NULL DEFAULT 'info',
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
"""

CREATE_ALERTS_TABLE = """
CREATE TABLE IF NOT EXISTS alerts (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp    TEXT NOT NULL,
    alert_type   TEXT NOT NULL,
    severity     TEXT NOT NULL DEFAULT 'medium',
    source_ip    TEXT,
    username     TEXT,
    hostname     TEXT,
    description  TEXT NOT NULL,
    details      TEXT,
    created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);
"""

CREATE_PROCESSES_TABLE = """
CREATE TABLE IF NOT EXISTS processes (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp      TEXT NOT NULL,
    hostname       TEXT NOT NULL,
    pid            INTEGER NOT NULL,
    process_name   TEXT NOT NULL,
    username       TEXT,
    command_line   TEXT,
    is_suspicious  INTEGER NOT NULL DEFAULT 0,
    matched_rule   TEXT,
    created_at     TEXT NOT NULL DEFAULT (datetime('now'))
);
"""

CREATE_FAILED_LOGINS_TABLE = """
CREATE TABLE IF NOT EXISTS failed_logins (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp   TEXT NOT NULL,
    hostname    TEXT,
    username    TEXT,
    source_ip   TEXT,
    message     TEXT,
    log_id      INTEGER,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(timestamp, username, source_ip)
);
"""

CREATE_PORT_SCANS_TABLE = """
CREATE TABLE IF NOT EXISTS port_scans (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp       TEXT NOT NULL,
    hostname        TEXT,
    source_ip       TEXT NOT NULL,
    ports_scanned   TEXT,
    port_count      INTEGER NOT NULL DEFAULT 0,
    alert_id        INTEGER,
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);
"""

# Indexes to keep detector queries (which filter/sort by time & type) fast
# even as the tables grow.
CREATE_INDEXES = [
    "CREATE INDEX IF NOT EXISTS idx_logs_timestamp ON logs(timestamp);",
    "CREATE INDEX IF NOT EXISTS idx_logs_event_type ON logs(event_type);",
    "CREATE INDEX IF NOT EXISTS idx_logs_source_ip ON logs(source_ip);",
    "CREATE INDEX IF NOT EXISTS idx_alerts_timestamp ON alerts(timestamp);",
    "CREATE INDEX IF NOT EXISTS idx_alerts_alert_type ON alerts(alert_type);",
    "CREATE INDEX IF NOT EXISTS idx_processes_is_suspicious "
    "ON processes(is_suspicious);",
    "CREATE INDEX IF NOT EXISTS idx_failed_logins_timestamp "
    "ON failed_logins(timestamp);",
    "CREATE INDEX IF NOT EXISTS idx_failed_logins_source_ip "
    "ON failed_logins(source_ip);",
    "CREATE INDEX IF NOT EXISTS idx_port_scans_timestamp "
    "ON port_scans(timestamp);",
    "CREATE INDEX IF NOT EXISTS idx_port_scans_source_ip "
    "ON port_scans(source_ip);",
]

ALL_SCHEMA_STATEMENTS: list[str] = [
    CREATE_LOGS_TABLE,
    CREATE_ALERTS_TABLE,
    CREATE_PROCESSES_TABLE,
    CREATE_FAILED_LOGINS_TABLE,
    CREATE_PORT_SCANS_TABLE,
    *CREATE_INDEXES,
]
