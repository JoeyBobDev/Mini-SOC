# Mini SOC — Setup Guide

This guide walks through installing and running Mini SOC from scratch on
Linux, Windows, and in a "demo mode" that doesn't require access to real
system logs.

---

## 1. Prerequisites

- Python **3.10** or newer
- pip (Python package manager)
- (Linux) read access to `/var/log/auth.log` or `/var/log/syslog` — usually
  requires `sudo`, or membership in the `adm`/`syslog` group
- (Windows) ability to read the Security Event Log — usually requires running
  as Administrator, and `pywin32` installed

---

## 2. Installation

```bash
# 1. Unzip / clone the project
cd mini_soc

# 2. Create a virtual environment
python3 -m venv venv

# 3. Activate it
source venv/bin/activate          # Linux / macOS
venv\Scripts\activate.bat         # Windows (cmd)
venv\Scripts\Activate.ps1         # Windows (PowerShell)

# 4. Install dependencies
pip install -r requirements.txt
```

`requirements.txt` installs Flask, psutil, pytest, and (on Windows only)
pywin32, which is conditionally installed via the `sys_platform == "win32"`
marker.

---

## 3. Running on Linux (real logs)

Reading `/var/log/auth.log` typically requires elevated permissions:

```bash
sudo venv/bin/python app.py
```

Alternatively, add your user to the group that owns the log file
(commonly `adm` on Debian/Ubuntu):

```bash
sudo usermod -aG adm $USER
# log out and back in for the group change to take effect
python app.py
```

Once running, visit **http://127.0.0.1:5000**.

To generate real failed-login events for testing, SSH into the machine with
a wrong password a few times from another terminal:

```bash
ssh definitely-not-a-real-user@localhost
```

---

## 4. Running on Windows (real logs)

1. Open **PowerShell as Administrator**.
2. Activate your virtual environment.
3. Run:
   ```powershell
   python app.py
   ```
4. Visit **http://127.0.0.1:5000**.

To generate real failed-login events, attempt to log in (RDP or local) with
an incorrect password a few times.

> **Note:** Reading the Security Event Log without Administrator rights will
> raise a permissions error, which Mini SOC catches and logs to
> `logs/application.log` without crashing the app.

---

## 5. Running in Demo Mode (no root / no real logs needed)

If you don't have access to real system logs (e.g. running in a Docker
container, a sandboxed environment, or on macOS where these files don't
exist in the same form), Mini SOC can be pointed at the bundled sample log
files instead — set `MINI_SOC_DEMO=1` to force this regardless of what
real log files or `journalctl` are available:

```bash
MINI_SOC_DEMO=1 python app.py
```

(Equivalently, you can set `MINI_SOC_AUTH_LOG` / `MINI_SOC_SYSLOG` to point
at specific files instead of using demo mode.)

In a second terminal, run the demo generator to simulate a brute-force
attack and a port scan:

```bash
python scripts/generate_demo_data.py
```

Within ~10–25 seconds, the dashboard's **Failed Login Alerts** and
**Port Scan Alerts** counters and the **Recent Alerts** table will update
automatically (no page refresh needed).

---

## 6. Testing the Port Scan Detector

The port scan detector reads the OS network connection table via `psutil`,
which it polls once per detection cycle (every 15s by default) — it is
**not** a packet capture. This matters in practice: `generate_demo_data.py`
(above) already triggers it reliably by opening 25 loopback connections and
holding them open for 20 seconds, long enough to guarantee the next poll
catches them.

If you'd rather trigger it manually with `nmap`:

```bash
# In another terminal, while Mini SOC is running:
nmap -p 1-100 localhost
```

This can trigger a `port_scan` alert, but **is not guaranteed to** — a fast
scan against closed ports opens and closes connections in well under a
second, and if that happens between two polls, `psutil.net_connections()`
never sees it. Verified experimentally: `nmap -T4 -p 1-100 127.0.0.1`
against closed ports produced zero alerts, while `generate_demo_data.py`'s
held-open-connections approach triggered one every time. If you want a
guaranteed live demo, prefer the demo script or scan a wider, slower range
(`nmap -p 1-1000 -T2 localhost`) to increase the odds a poll lands mid-scan.

If `nmap` isn't installed:

```bash
# Debian/Ubuntu
sudo apt-get install nmap

# macOS
brew install nmap
```

---

## 7. Testing the Suspicious Process Detector

Run any process whose name or command line matches an entry in
`Config.SUSPICIOUS_PROCESS_BLACKLIST` (default includes `ncat`, `netcat`,
`nc.exe`, `mimikatz`, `psexec`, etc.):

```bash
# Linux/macOS (ncat ships with nmap)
ncat -l 4444
```

Within one process-scan cycle (default: every 15 seconds), this process
will appear in the **Suspicious Processes** table with the matched rule
highlighted.

> You can freely edit the `blacklist:` list in `config.yaml` to add or
> remove blacklisted process names — no code changes required. (`config.py`
> also has a built-in default list, used only if `config.yaml` is missing
> or doesn't define `blacklist:`.)

---

## 8. Environment Variables Reference

| Variable | Purpose | Default |
|---|---|---|
| `MINI_SOC_AUTH_LOG` | Override path to the auth/security log | `/var/log/auth.log` |
| `MINI_SOC_SYSLOG` | Override path to the syslog | `/var/log/syslog` |
| `MINI_SOC_HOST` | Dashboard bind address | `0.0.0.0` |
| `MINI_SOC_PORT` | Dashboard port | `5000` |
| `MINI_SOC_DEBUG` | Enable Flask debug mode (`true`/`false`) | `false` |
| `MINI_SOC_DEMO` | Force `sample_logs/` as the log source, ignoring real system logs/journald (`true`/`1`/`yes`) | `false` |

---

## 9. Running the Test Suite

```bash
pytest tests/ -v
```

All tests use temporary SQLite files and mocked `psutil` calls — they never
touch your real system logs, processes, or network connections.

---

## 10. Stopping the Application

Press `CTRL+C` in the terminal running `app.py`. The background collector
and detection threads are daemon threads and will stop automatically when
the main process exits.

---

## 11. Troubleshooting

| Symptom | Likely Cause | Fix |
|---|---|---|
| Dashboard loads but shows 0 logs | Log file paths not found / no read permission | Check `logs/application.log` for warnings; verify `MINI_SOC_AUTH_LOG` / real path exists and is readable |
| `PermissionError` reading auth.log | Insufficient privileges | Run with `sudo`, or add your user to the log-owning group |
| Port scan alerts never fire | `psutil.net_connections()` requires elevated privileges on some OSes | Run with `sudo` / Administrator |
| `ModuleNotFoundError: pywin32` on Linux | Expected — pywin32 only installs on Windows | Ignore; WindowsCollector safely no-ops on non-Windows platforms |
| Dashboard doesn't auto-update | JavaScript blocked or `dashboard.js` not loading | Check browser console; verify static files are served under `/static/` |
