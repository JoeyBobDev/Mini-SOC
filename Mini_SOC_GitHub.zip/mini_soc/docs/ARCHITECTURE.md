# Mini SOC — Architecture

## 1. High-Level Overview

Mini SOC follows a classic **collect → detect → present** security
monitoring pipeline, implemented as three loosely-coupled subsystems that
share a single SQLite database as their integration point:

```
┌──────────────────┐     ┌──────────────────┐     ┌──────────────────┐
│   COLLECTION      │     │    DETECTION      │     │    PRESENTATION   │
│   (background      │     │   (background      │     │   (Flask, main    │
│    thread)          │     │    thread)          │     │    thread)         │
│                    │     │                    │     │                    │
│  LinuxCollector /  │────▶│ FailedLoginDetector│────▶│  dashboard/routes  │
│  WindowsCollector  │     │ PortScanDetector   │     │  templates + JS    │
│                    │     │ ProcessDetector    │     │  auto-refresh      │
└─────────┬──────────┘     └─────────┬──────────┘     └─────────┬──────────┘
          │                          │                          │
          └──────────────┬───────────┴──────────────────────────┘
                          ▼
                 ┌──────────────────┐
                 │   SQLite Database  │
                 │  logs / alerts /   │
                 │  processes tables  │
                 └──────────────────┘
```

Each subsystem only depends on the database schema (via `DatabaseManager`),
never on each other directly. This means:

- The collector doesn't know detectors exist.
- Detectors don't know the dashboard exists.
- The dashboard doesn't know how logs got into the database.

This decoupling is what makes the codebase "modular and easy to understand"
— each piece can be read, tested, and modified in isolation.

---

## 2. Process / Threading Model

`app.py` is the composition root. On startup it:

1. Initializes `DatabaseManager` (creates tables if they don't exist).
2. Starts a **daemon thread** running `LogCollectionService.run_forever()`
   — polls the OS log files every `POLLING_INTERVAL_SECONDS` (default 10s).
3. Starts a second **daemon thread** running `DetectionService.run_forever()`
   — runs all three detectors every `PROCESS_SCAN_INTERVAL_SECONDS` (default
   15s).
4. Runs the Flask development server in the **main thread**, serving HTTP
   requests.

```python
collector_thread = threading.Thread(target=collection_service.run_forever, daemon=True)
detector_thread  = threading.Thread(target=detection_service.run_forever, daemon=True)
```

Because both background threads are marked `daemon=True`, they are
automatically killed when the main Flask process exits (e.g. on `CTRL+C`) —
no explicit thread-join logic is required for a simple portfolio project,
though `atexit` is still used to call `.stop()` on each service for a
cleaner shutdown log trail.

### Why threads instead of async or multiprocessing?

- **Threads** are the simplest model for I/O-bound polling work (reading
  files, querying `psutil`, hitting SQLite) and keep the codebase
  approachable for an entry-level project.
- **Multiprocessing** would add IPC complexity (SQLite doesn't share
  connections across processes well without extra care) for no real benefit
  at this scale.
- **Async** (asyncio) would require rewriting Flask routes and all I/O calls
  in async style, adding conceptual overhead disproportionate to the
  project's scope.

### Concurrency safety

`DatabaseManager` opens a **new short-lived SQLite connection per
operation**, wrapped in a `threading.Lock`, and enables **WAL (Write-Ahead
Logging) mode**. This means:

- Multiple threads can safely call `insert_log()`, `insert_alert()`, etc.
  without corrupting the database.
- Flask's request-handling thread(s) can read from the database
  concurrently with the collector/detector threads writing to it.

---

## 3. Data Flow: Log Collection

1. `LogCollectionService.run_forever()` wakes up every N seconds.
2. It calls `collector.collect()`, which:
   - For `LinuxCollector`: tails `auth.log` and `syslog` from the last read
     byte offset (`BaseCollector._tail_new_lines`), applies regex patterns to
     classify each new line (`failed_login`, `accepted_login`, `generic`),
     and builds a `NormalizedLog` for each match.
   - For `WindowsCollector`: reads new records from the Windows Security
     Event Log via `pywin32`, filters the Security channel for Event IDs
     4624/4625/4740, and builds a `NormalizedLog` for each.
3. Each `NormalizedLog` is persisted via `db_manager.insert_log(...)`.

The **normalized schema** (`utils/json_normalizer.py`) is the contract that
lets detectors stay OS-agnostic:

```json
{
  "timestamp": "2026-01-10T03:14:15+00:00",
  "hostname": "web01",
  "event_type": "failed_login",
  "username": "admin",
  "source_ip": "203.0.113.5",
  "message": "Failed password for invalid user admin from 203.0.113.5 port 51514 ssh2",
  "severity": "medium"
}
```

---

## 4. Data Flow: Detection

`DetectionService.run_forever()` wakes up every N seconds and runs three
independent detectors in sequence:

### FailedLoginDetector
- Queries `logs` for `event_type = 'failed_login'` within the last
  `FAILED_LOGIN_WINDOW_SECONDS`.
- Groups results by `source_ip` (falling back to `username`).
- If any group has `>= FAILED_LOGIN_THRESHOLD` entries, and no matching
  alert was already raised in the current window
  (`alert_exists_recently`), inserts a new row into `alerts`.

### PortScanDetector
- Calls `psutil.net_connections(kind="inet")` each cycle to snapshot the
  OS's current connection table.
- Appends `(timestamp, remote_ip, local_port)` sightings to an in-memory
  sliding-window buffer (a `deque`), pruning entries older than
  `PORT_SCAN_WINDOW_SECONDS`.
- Groups remaining sightings by `remote_ip` and counts **distinct**
  `local_port` values touched.
- If any IP exceeds `PORT_SCAN_PORT_THRESHOLD`, raises an alert (again with
  duplicate suppression via `alert_exists_recently`).

### ProcessDetector
- Calls `psutil.process_iter(["pid", "name", "username", "cmdline"])` each
  cycle to enumerate running processes.
- For each process, checks the process **name** for an exact/`.exe`-suffix
  match against `Config.SUSPICIOUS_PROCESS_BLACKLIST`, and the command line
  for a case-insensitive, word-boundary-aware regex match (so `ncat` matches
  `/usr/bin/ncat` but not e.g. `syncat`). A small built-in allowlist of
  common benign process names (`bash`, `python`, `sshd`, etc.) is excluded
  from name matching to cut down on short-token false positives (e.g. `nc`).
- Newly-matched PIDs are inserted into `processes` (with `is_suspicious=1`)
  and an alert is raised. Already-flagged PIDs are tracked in memory
  (`self._flagged_pids`) to avoid re-alerting every cycle for the same
  still-running process.

### Duplicate-alert suppression strategy

Both `FailedLoginDetector` and `PortScanDetector` call
`DatabaseManager.alert_exists_recently(alert_type, source_ip, since_iso)`
before inserting a new alert. This performs a simple
`SELECT COUNT(*) ... WHERE alert_type = ? AND source_ip IS ? AND timestamp >= ?`
query — if an alert for the same type/source has already fired within the
current window, no duplicate is raised. This keeps the `alerts` table
useful and readable instead of being flooded with one alert per poll cycle
during an ongoing attack.

`ProcessDetector` uses a different strategy — an in-memory PID set — since
process identity (PID) is a cleaner "already handled" key than a
time-window check.

---

## 5. Data Flow: Presentation

- `GET /` renders `dashboard.html` **server-side** on first load (via
  Jinja2), using `DatabaseManager.get_statistics()`,
  `get_recent_logs()`, `get_recent_alerts()`, and
  `get_recent_suspicious_processes()`.
- `dashboard.js` then polls four JSON endpoints
  (`/api/stats`, `/api/logs`, `/api/alerts`, `/api/processes`) every 5
  seconds (`dashboard.refresh_interval_seconds` in `config.yaml`) and
  re-renders the stat cards and tables client-side, without a full page
  reload — this gives the dashboard a "live SOC console" feel.

The dashboard is intentionally **read-only** — there is no way to modify
data through the web UI. This is a deliberate scope boundary: this is a
monitoring tool, not an incident-management system.

---

## 6. Database Schema Design

Three tables, each independently indexed for the query patterns the
detectors and dashboard actually run:

```sql
logs(id, timestamp, hostname, event_type, username, source_ip, message, severity, created_at)
  INDEX on (timestamp), (event_type), (source_ip)

alerts(id, timestamp, alert_type, severity, source_ip, username, hostname, description, details, created_at)
  INDEX on (timestamp), (alert_type)

processes(id, timestamp, hostname, pid, process_name, username, command_line, is_suspicious, matched_rule, created_at)
  INDEX on (is_suspicious)
```

`details` on the `alerts` table stores a JSON blob (e.g. the list of
distinct ports for a port-scan alert, or usernames targeted in a
brute-force attempt) — this keeps the relational schema simple while still
preserving rich, structured context for each alert.

---

## 7. Configuration-Driven Design

Every threshold, blacklist entry, file path, and interval lives in
`config.py` as a single `Config` class with class-level constants. No
module hard-codes a magic number — e.g. `FailedLoginDetector.__init__`
defaults to `Config.FAILED_LOGIN_THRESHOLD` but also accepts an explicit
override, which is what makes the detectors independently unit-testable
without monkeypatching global config state (see `tests/test_detectors.py`,
which passes `threshold=5, window_seconds=120` directly).

---

## 8. Cross-Platform Strategy

Windows and Linux log sources are fundamentally different (Event Log API vs
flat text files), so the platform-specific logic is fully isolated inside
`collector/linux_collector.py` and `collector/windows_collector.py`, both
implementing the same `BaseCollector.collect() -> list[NormalizedLog]`
interface. `collector/log_collector.py` picks the right implementation at
runtime via `platform.system()`. Everything downstream of `collect()` —
detectors, database, dashboard — is completely platform-agnostic.

`WindowsCollector` guards its `pywin32` import with a `try/except
ImportError`, so importing the module never crashes on Linux/macOS; calling
`collect()` on a non-Windows platform simply logs a warning and returns an
empty list.

---

## 9. Extensibility Points

The architecture was designed so a future contributor could add:

- **A new detector** — implement a class with a `.scan() -> int` method
  that reads from `DatabaseManager` and calls `insert_alert()`; register it
  in `DetectionService.__init__`.
- **A new log source** (e.g. macOS unified logs, cloud audit logs) —
  implement `BaseCollector.collect()`; register it in
  `build_platform_collector()`.
- **A new alert type in the UI** — no dashboard changes needed; alerts are
  rendered generically by `alert_type`/`severity`/`description`.

...without touching any other subsystem — a direct benefit of the
collect/detect/present separation described above.
