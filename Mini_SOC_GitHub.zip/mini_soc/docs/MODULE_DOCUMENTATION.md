# Mini SOC — Module Documentation

This document explains what every file in the project does, its key
classes/functions, and how it fits into the whole. Read alongside
`ARCHITECTURE.md` for the bigger picture.

---

## `app.py`

The composition root. Contains:

- `create_app(db_manager) -> Flask` — application factory; builds the Flask
  app, stores the shared `DatabaseManager` on `app.config["DB_MANAGER"]`,
  registers the `dashboard_bp` blueprint.
- `start_background_services(db_manager)` — builds `LogCollectionService`
  and `DetectionService`, wraps each in a daemon `threading.Thread`, starts
  both, returns them so the caller can `.stop()` them on shutdown.
- `main()` — the actual `python app.py` entry point: ensures directories
  exist, builds the DB manager, starts background services, registers an
  `atexit` shutdown hook, and runs `app.run(...)`.

`use_reloader=False` is set deliberately — Flask's debug reloader spawns a
second process, which would double-start the background threads.

---

## `config.py`

A single `Config` class holding every tunable value as a class attribute:
paths (`BASE_DIR`, `LOGS_DIR`, `DATA_DIR`, `DATABASE_PATH`), log source
candidates (`LINUX_AUTH_LOG_PATHS`, `LINUX_SYSLOG_PATHS`,
`WINDOWS_EVENT_LOG_CHANNEL`), polling intervals, detection thresholds
(`FAILED_LOGIN_THRESHOLD`, `PORT_SCAN_PORT_THRESHOLD`, etc.), the process
blacklist (`SUSPICIOUS_PROCESS_BLACKLIST`), and dashboard settings (host,
port, debug, page-size limits).

`Config.ensure_directories()` is a classmethod called at startup (and by
the logger) to create `logs/` and `data/` if missing.

Log source paths can be overridden via environment variables
(`MINI_SOC_AUTH_LOG`, `MINI_SOC_SYSLOG`) — useful for demos/sandboxes
without access to real `/var/log` files.

---

## `utils/logger.py`

Provides `get_logger(module_name) -> logging.Logger`. Internally,
`_configure_root_logger()` runs once (guarded by a module-level
`_configured` flag) and attaches:

- A `RotatingFileHandler` writing to `Config.APP_LOG_FILE`
  (`logs/application.log`), capped at 5MB with 3 backups.
- A `StreamHandler` for console output.

Every other module calls `get_logger(__name__)` at import time, so all logs
share one consistent format:
`YYYY-MM-DD HH:MM:SS | LEVEL | mini_soc.module.name | message`.

---

## `utils/json_normalizer.py`

Defines the **canonical log schema** used throughout the app:

- `NormalizedLog` — a `@dataclass` with fields `timestamp`, `hostname`,
  `event_type`, `username`, `source_ip`, `message`, `severity`.
  `__post_init__` guards against invalid severity strings, falling back to
  `"info"`.
- `now_iso()` — returns the current UTC time as an ISO-8601 string.
- `build_normalized_log(...)` — factory function collectors call to build a
  `NormalizedLog` without importing the dataclass directly.

This is the single most important "contract" in the codebase: as long as a
collector produces `NormalizedLog` objects, detectors and the dashboard
never need to know anything about where the data came from.

---

## `database/models.py`

Pure SQL — no logic. Three `CREATE TABLE IF NOT EXISTS` statements
(`logs`, `alerts`, `processes`) plus a list of `CREATE INDEX IF NOT EXISTS`
statements for the columns detectors/dashboard filter or sort by most
often (`timestamp`, `event_type`, `source_ip`, `alert_type`,
`is_suspicious`). `ALL_SCHEMA_STATEMENTS` bundles everything for
`DatabaseManager` to execute on startup.

---

## `database/db_manager.py`

The **only** place in the codebase that touches SQL directly. Key design
points:

- `_get_connection()` — a context manager that opens a fresh
  `sqlite3.Connection` per call (row factory = `sqlite3.Row` for dict-like
  access), enables `PRAGMA journal_mode=WAL`, commits on success, rolls
  back and logs on `sqlite3.Error`, always closes the connection.
- A `threading.Lock` wraps every operation so concurrent threads (collector,
  detectors, Flask request handlers) never race on the same connection
  object.
- CRUD methods grouped by table:
  - **Logs:** `insert_log`, `get_recent_logs`, `get_logs_by_event_type`,
    `count_logs`
  - **Alerts:** `insert_alert`, `get_recent_alerts`,
    `count_alerts_by_type`, `alert_exists_recently` (duplicate-alert
    suppression check)
  - **Processes:** `insert_process`, `get_recent_suspicious_processes`,
    `count_suspicious_processes`
- `get_statistics()` — a single method running four `COUNT(*)` queries
  used to populate the dashboard's stat cards in one call.

`insert_alert(..., details: dict | None)` serializes `details` to a JSON
string before storage (e.g. `{"distinct_ports": [...], "port_count": 24}`),
keeping the schema flat while preserving structured context.

---

## `collector/base_collector.py`

Abstract base class (`ABC`) all collectors inherit from.

- `collect() -> list[NormalizedLog]` — abstract; subclasses implement.
- `_tail_new_lines(file_path) -> list[str]` — the key reusable utility.
  Tracks a byte offset per file in `self._file_offsets`. On each call, seeks
  to the last-read offset, reads to EOF, updates the offset, and returns
  only the newly-appended, non-empty lines. Detects log rotation (file
  shrank since last read) and resets the offset to 0 in that case. On the
  very first call for a given file, starts from offset 0 (ingesting
  existing content) rather than the end of the file — appropriate for a
  monitoring tool that should show recent history immediately on startup.
- `get_hostname()` — static helper wrapping `os.uname()` (Linux/macOS) or
  `COMPUTERNAME` (Windows fallback).

---

## `collector/linux_collector.py`

Implements `BaseCollector` for Linux.

- `__init__` resolves the first existing/readable path from
  `Config.LINUX_AUTH_LOG_PATHS` and `Config.LINUX_SYSLOG_PATHS`.
- `collect()` tails both files and parses each new line.
- Regex patterns:
  - `_RE_FAILED_PASSWORD` — matches `Failed password for [invalid user]
    USER from IP port PORT`.
  - `_RE_ACCEPTED_PASSWORD` — matches `Accepted password|publickey for USER
    from IP port PORT`.
  - `_RE_SUDO_FAILURE` — matches `sudo: ... authentication failure ...
    user=USER`.
  - `_RE_SYSLOG_PREFIX` — matches the standard syslog line prefix (`Mon DD
    HH:MM:SS hostname process[pid]: message`) to extract timestamp/host and
    hand the remaining message body to the more specific patterns above.
- `_parse_timestamp()` — converts syslog's year-less timestamp format
  (`Mon DD HH:MM:SS`) into a full ISO-8601 string by assuming the current
  year (a known limitation of classic syslog format — documented, not
  hidden).
- `_parse_auth_line()` / `_parse_syslog_line()` — return a `NormalizedLog`
  or `None` if the line doesn't match anything interesting.

---

## `collector/windows_collector.py`

Implements `BaseCollector` for Windows using `pywin32`.

- Imports `win32evtlog` etc. inside a `try/except ImportError`, setting
  `_PYWIN32_AVAILABLE = False` on any other platform so the module always
  imports cleanly.
- `collect()` iterates every configured channel (`Security` and `System` by
  default), reads events backwards from the most recent, and stops once it
  reaches a record number already seen for that channel
  (`self._last_record_numbers`, one cursor per channel) — avoiding
  re-processing the same events every poll.
- `_parse_event()` filters the `Security` channel for Event IDs 4625 (failed
  logon), 4624 (successful logon), and 4740 (account lockout); `System`
  channel events are captured generically. Username/source IP are extracted
  from `event.StringInserts` (positions 5 and 19 respectively, per the
  standard 4624/4625 field layout; 4740's target username is at position 0),
  and a `NormalizedLog` is built for each.
- Any unexpected exception during log reading is caught, logged via
  `logger.exception(...)`, and results in an empty return rather than a
  crash.

---

## `collector/log_collector.py`

The orchestrator.

- `build_platform_collector()` — uses `platform.system()` to instantiate
  `WindowsCollector` or `LinuxCollector` (defaulting to `LinuxCollector` on
  unrecognized platforms, which will simply find no log files and collect
  nothing rather than crash).
- `LogCollectionService` — wraps a collector instance in a polling loop:
  - `run_once()` — calls `collector.collect()`, persists each result via
    `db_manager.insert_log(...)`, returns the count inserted. Catches and
    logs any exception from `collect()` so one bad log line never crashes
    the whole service.
  - `run_forever()` — loops `run_once()` + `time.sleep(interval)` until
    `stop()` is called.

---

## `detectors/failed_login_detector.py`

`FailedLoginDetector.scan()`:

1. Computes the window start timestamp
   (`now - FAILED_LOGIN_WINDOW_SECONDS`).
2. Fetches all `failed_login` logs since that timestamp.
3. Groups them by `source_ip` (falling back to `username` if no IP is
   present — e.g. local `sudo` failures).
4. For each group at or above `FAILED_LOGIN_THRESHOLD`, checks
   `alert_exists_recently` to avoid duplicate alerts, then inserts a new
   `alerts` row with severity `"high"` if the count is double the
   threshold or more, else `"medium"`, and structured `details` (attempt
   count, usernames targeted, window size).

---

## `detectors/port_scan_detector.py`

`PortScanDetector.scan()`:

1. `_capture_current_connections()` — snapshots `psutil.net_connections
   (kind="inet")`, appending `(now, remote_ip, local_port)` tuples to an
   in-memory `deque` (loopback traffic is intentionally **not** filtered
   out, so the detector can be exercised locally with tools like `nmap -p
   1-100 localhost`).
2. `_prune_old_sightings()` — drops sightings older than
   `PORT_SCAN_WINDOW_SECONDS` from the left of the deque.
3. Groups remaining sightings by `remote_ip`, computes the set of distinct
   `local_port` values touched by each.
4. Any IP at or above `PORT_SCAN_PORT_THRESHOLD` distinct ports (and not
   already alerted this window) gets a new `"high"` severity alert with
   the full sorted port list in `details`.

Handles `psutil.AccessDenied` gracefully (some connection states require
elevated privileges on some OSes) by logging a warning instead of crashing.

---

## `detectors/process_detector.py`

`ProcessDetector.scan()`:

1. Iterates `psutil.process_iter(["pid", "name", "username", "cmdline"])`.
2. For each process, `_match_blacklist()` checks the process name for an
   exact or `.exe`-suffix match against the blacklist, then falls back to a
   case-insensitive, word-boundary-aware regex match against the command
   line (so `ncat` matches `/usr/bin/ncat` or `ncat -l 4444` but not an
   unrelated binary that merely contains the substring). Names in the
   built-in `_BENIGN_PROCESS_NAMES` allowlist (`bash`, `python`, `sshd`,
   common desktop/session processes, etc.) are skipped entirely to reduce
   false positives on short tokens like `nc`.
3. Skips PIDs already in `self._flagged_pids` (already alerted this run).
4. On a new match: inserts a `processes` row (`is_suspicious=1`,
   `matched_rule=<token>`) and a `"critical"` severity alert.
5. At the end of each scan, intersects `self._flagged_pids` with the set of
   currently-active PIDs, so PIDs that have exited are "forgotten" (a
   future process reusing that PID number will be re-evaluated fresh).

---

## `detectors/detection_service.py`

The orchestrator, mirroring `LogCollectionService`'s shape:

- `DetectionService.__init__` builds one instance each of
  `FailedLoginDetector`, `PortScanDetector`, `ProcessDetector`, sharing the
  same `DatabaseManager`.
- `run_once()` calls all three `.scan()` methods, catching and logging any
  exception from each independently (so a bug in one detector can't take
  down the other two), and returns a dict of alert counts per detector.
- `run_forever()` / `stop()` mirror the collector service's polling loop.

---

## `dashboard/routes.py`

A Flask `Blueprint` (`dashboard_bp`) with five routes:

- `GET /` — server-renders `dashboard.html` with initial data
  (`get_statistics`, `get_recent_logs`, `get_recent_alerts`,
  `get_recent_suspicious_processes`). Wrapped in try/except so a database
  hiccup shows an empty dashboard instead of a 500 error.
- `GET /api/stats`, `/api/logs`, `/api/alerts`, `/api/processes` — thin
  JSON wrappers around the same `DatabaseManager` methods, used by
  `dashboard.js` for auto-refresh.

`_get_db()` pulls the shared `DatabaseManager` from
`current_app.config["DB_MANAGER"]`, which `app.py`'s `create_app()` sets —
this indirection is what lets the blueprint be imported and tested without
needing to know how the app was constructed.

---

## `dashboard/templates/base.html` & `dashboard.html`

- `base.html` — shared layout: Bootstrap 5 + Bootstrap Icons via CDN, a
  dark navbar, a content block, and a footer. Loads
  `dashboard/static/css/style.css` and (per-page) any additional scripts.
- `dashboard.html` — extends `base.html`. Contains:
  - Six **stat cards** (Total Logs, Total Alerts, Failed Login Alerts,
    Port Scan Alerts, Suspicious Processes, a "Live" status indicator).
  - A **Recent Alerts** table (time, type badge, severity badge, source,
    description).
  - A **Recent Logs** table (time, event type badge, user, source IP,
    message).
  - A **Suspicious Processes** table (time, PID, process name, user,
    matched rule badge, command line).
  - Jinja2 `{% for %}...{% else %}` blocks render an empty-state message
    ("No alerts yet.", etc.) when a table has no rows.

---

## `dashboard/static/css/style.css`

Custom styling layered on top of Bootstrap: a dark navbar color, stat-card
layout with a large background icon, scrollable table containers with
sticky headers, and severity-colored badges (`.severity-info` through
`.severity-critical`).

---

## `dashboard/static/js/dashboard.js`

Vanilla JS, no framework. `REFRESH_INTERVAL_MS` defaults to `5000` but is
overridden by the server-rendered `window.SOC_REFRESH_INTERVAL`, which comes
from `dashboard.refresh_interval_seconds` in `config.yaml` (default: 5s).
Four `async`
functions (`refreshStats`, `refreshAlerts`, `refreshLogs`,
`refreshProcesses`) each `fetch()` their corresponding `/api/...` endpoint
and rebuild the relevant DOM (`textContent` for stat numbers,
`innerHTML` template strings for table bodies). `escapeHtml()` guards
against HTML injection from log/alert content before interpolating it into
`innerHTML`. `refreshAll()` calls all four and is wired to `setInterval`.

---

## `scripts/generate_demo_data.py`

A standalone script (not part of the running application, and not a
database client — it never imports `DatabaseManager`) that:

1. Truncates and rewrites `sample_logs/auth.log` and `sample_logs/syslog`
   for a clean, reproducible starting state each run.
2. Appends synthetic, realistic-looking lines — a handful of benign login
   events, a burst of 8 failed-login attempts from one fake attacker IP
   (exceeding the default threshold of 5), and 3 sudo authentication
   failures.
3. Opens 25 loopback TCP connections and holds them open for ~20 seconds
   to reliably exercise `PortScanDetector` (see `ARCHITECTURE.md` and
   `INTERVIEW_QA.md` Q45 for why a fast `nmap`-style scan is not reliable
   against a polling-based detector).

Every event reaches the database only via the real
`LogCollectionService` → `DetectionService` pipeline, exactly like a real
attack would — this script deliberately does not shortcut that path with
direct database writes, so running it is a genuine end-to-end test of the
whole application.

---

## `tests/`

- `test_database.py` — exercises every `DatabaseManager` method against a
  temporary SQLite file (via pytest's `tmp_path` fixture).
- `test_detectors.py` — tests all three detectors with `psutil` calls
  monkeypatched to return controlled fake data (fake connections, fake
  processes), so tests are deterministic and don't depend on the host
  machine's actual state.
- `test_collector.py` — tests `LinuxCollector`'s regex-based line parsing
  against temporary log files, including verifying that only newly
  appended lines are re-read on subsequent calls.
