# Mini SOC — Interview Q&A Guide

40+ questions you could reasonably be asked about this project in a
technical interview, organized by category, with model answers written
from the perspective of someone who built it.

---

## A. Project Overview & Scope

**1. What does this project do, in one sentence?**
Mini SOC collects local operating system logs, detects three classic
attack patterns (brute-force logins, port scans, and blacklisted
processes), and displays everything in real time on a Flask/Bootstrap
dashboard backed by SQLite.

**2. Why did you build this?**
To demonstrate practical, end-to-end understanding of the SOC analyst
workflow — log collection, normalization, detection logic, and
alert triage — using a codebase small enough to fully own and explain,
rather than configuring an off-the-shelf SIEM I didn't build myself.

**3. Why didn't you use Elasticsearch/Kibana/a real SIEM?**
Scope discipline. The goal was to demonstrate the *concepts* behind log
collection and detection engineering clearly, not to integrate third-party
infrastructure. Adding Elasticsearch would mean most of the "work" is
configuration rather than code I designed, and it would obscure the
core logic under infrastructure complexity that isn't the point of an
entry-level portfolio piece.

**4. What would you add if this were a production system?**
Centralized log shipping (Filebeat/Fluentd) instead of local file tailing,
a real time-series/search backend (Elasticsearch or OpenSearch) instead of
SQLite, a rules engine (Sigma) for more expressive detection logic,
authentication on the dashboard, alert notification channels (email/Slack/
PagerDuty), and horizontal scaling via a message queue between collection
and detection.

**5. How long did this take to build, and what was hardest?**
(Answer based on your own experience — but a reasonable model answer:) The
detection logic itself was straightforward; the trickiest part was
designing duplicate-alert suppression so an ongoing attack doesn't flood
the alerts table with one alert per polling cycle, while still being
simple enough to unit test deterministically.

---

## B. Architecture & Design Decisions

**6. Walk me through the architecture.**
Three independent components — a log collector, a detection engine, and a
Flask dashboard — each running in their own thread (collector and detector
as daemon threads, dashboard on the main thread), communicating only
through a shared SQLite database. No component has a direct reference to
another; they're fully decoupled through the data layer.

**7. Why threads instead of multiprocessing or asyncio?**
Threads are the simplest concurrency model for I/O-bound polling work
(reading files, querying psutil, hitting SQLite), and Python's GIL isn't a
bottleneck here since the work is I/O-bound, not CPU-bound. Multiprocessing
would add IPC complexity for no real benefit at this scale, and asyncio
would require rewriting Flask routes and every I/O call in async style —
disproportionate overhead for this project's scope.

**8. How do you avoid SQLite corruption with multiple threads writing to it?**
Two mechanisms: SQLite's WAL (Write-Ahead Logging) mode, which allows one
writer and multiple concurrent readers without blocking, and a
`threading.Lock` in `DatabaseManager` that serializes write operations
from the Python side as an extra safety margin.

**9. Why did you choose polling over an event-driven design?**
Simplicity and testability. At single-host scale, re-querying a small,
indexed SQLite table every few seconds is easy to reason about and easy to
unit test deterministically (just insert rows, call `scan()`, assert on
the result) — no message broker or event loop complexity needed.

**10. What's the trade-off of polling?**
Detection latency is bounded by the polling interval rather than being
instantaneous. With default settings (10s collector, 15s detector), an
attack can take up to ~25-35 seconds to appear on the dashboard. That's
an acceptable trade-off for this project's scope.

**11. Why is the normalized log schema important?**
It decouples every downstream component from the OS-specific log format.
Windows Event Logs and Linux syslog look nothing alike, but once both are
converted into the same `{timestamp, hostname, event_type, username,
source_ip, message, severity}` shape at collection time, the detectors and
dashboard can be written once and work identically regardless of platform.

**12. Why is there no ORM?**
Transparency. With only three tables, raw DDL in `models.py` is easier to
read end-to-end than an ORM's generated schema, and it avoids adding a
dependency + abstraction layer that isn't earning its complexity budget at
this scale.

**13. How would this scale to monitoring 100 servers instead of 1?**
The current design (local file tailing + local SQLite) doesn't scale
horizontally as-is. I'd introduce a log-shipping agent per host (e.g.
Filebeat) forwarding to a central message queue or index, replace SQLite
with a proper time-series/search store, and separate the collector,
detector, and dashboard into independently-scalable services.

**14. Why is the dashboard read-only?**
Deliberate scope boundary — this is a monitoring tool, not an
incident-management or case-management system. Adding mutation (e.g.
acknowledging/closing alerts) would require auth, audit trails, and a
different data model, which is out of scope for an entry-level project.

**15. How does the dashboard stay "live" without WebSockets?**
Client-side JavaScript polls four JSON API endpoints
(`/api/stats`, `/api/logs`, `/api/alerts`, `/api/processes`) every 5
seconds (configurable via `dashboard.refresh_interval_seconds` in
`config.yaml`) via `fetch()` and patches the relevant DOM elements in
place. It's
not real-time in the WebSocket sense, but it's simple, has no persistent
connection overhead, and is indistinguishable from "live" at this refresh
rate for a human analyst.

---

## C. Detection Logic

**16. How does failed-login detection work?**
The detector queries the `logs` table for `event_type = 'failed_login'`
entries within the last N seconds (default 120), groups them by source IP
(falling back to username if no IP is available), and raises an alert if
any group has 5 or more entries — as long as no matching alert was already
raised in the current window.

**17. Why group by source IP with a username fallback?**
Source IP is the more reliable attacker identity for network-based
brute-force attempts. But some log sources (e.g. local `sudo` authentication
failures) don't have an associated IP, so falling back to username ensures
those attempts are still grouped and detected rather than silently ignored.

**18. How does the port scan detector work without raw packet capture?**
It uses `psutil.net_connections()`, which reads the OS's existing
connection table (the same data `netstat`/`ss` show) — no root privileges
or raw sockets required for most connection states. It maintains a rolling
in-memory buffer of `(remote_ip, local_port, timestamp)` sightings, prunes
entries older than the window, and counts distinct ports per remote IP.

**19. Why is the port-scan buffer in-memory instead of in the database?**
It's ephemeral, high-frequency data (potentially many connections per
second) that only matters within a short rolling window (60s by default).
Writing every connection sighting to SQLite would be wasteful I/O for data
we're about to discard; an in-memory `deque` with timestamp-based pruning
is the right tool for a short sliding window.

**20. How does suspicious process detection avoid false positives on legitimate uses of blacklisted terms?**
It doesn't fully, but it's more careful than a naive substring match: the
process **name** must equal a blacklist token (or that token + `.exe`), and
the **command line** is matched with a word-boundary-aware regex so `ncat`
matches `/usr/bin/ncat` but not an unrelated binary that merely contains
those letters. A small built-in allowlist (`bash`, `python`, `sshd`, common
desktop-session processes, etc.) is also excluded up front so short, common
tokens like `nc` don't fire on unrelated system processes. That said, it's
still name/pattern-based, not identity-based — a renamed binary evades it
entirely. A production system would use more precise matching (binary
hashes, signed binary allowlisting, or EDR-grade behavioral detection)
rather than name-based blacklisting alone.

**21. How do you prevent alert spam for an ongoing attack?**
Two different strategies depending on the detector: `FailedLoginDetector`
and `PortScanDetector` check `alert_exists_recently()` before inserting —
if an alert for the same type/source already fired within the current
window, no duplicate is raised. `ProcessDetector` instead tracks
already-flagged PIDs in memory, since PID is a cleaner "already handled"
identity than a time-window check for a still-running process.

**22. What happens if the same PID gets reused by a different, unrelated process?**
`ProcessDetector` removes PIDs from its `_flagged_pids` set once they're no
longer present in the running process list (`self._flagged_pids &=
active_pids`), so if a PID number is reused later by a different process,
it will be re-evaluated fresh rather than silently ignored forever.

**23. Why are thresholds configurable rather than hard-coded?**
Different environments have different baseline noise levels — a
threshold of 5 failed logins in 2 minutes might be too sensitive for a
busy multi-user server and too loose for a single-purpose server. Making
thresholds live in `config.py` (and accept constructor overrides) lets an
operator tune sensitivity without touching detection logic, and makes the
detectors independently unit-testable with explicit values.

**24. What severity levels does the system use, and how are they assigned?**
`info`, `low`, `medium`, `high`, `critical`. Login events default to
`info` (success) or `medium` (failure); failed-login alerts escalate to
`high` if the attempt count is double the threshold; port-scan alerts are
always `high`; suspicious-process alerts are always `critical` since a
blacklisted tool actually running is a strong signal.

**25. How would you reduce false positives in the port scan detector for legitimate scanning tools used by admins?**
Add an IP allowlist in config (e.g. known vulnerability-scanner or
monitoring-system IPs) that the detector checks before alerting, or
require a longer sustained pattern (e.g. scans repeated across multiple
windows) before escalating severity.

---

## D. Code Quality & Testing

**26. How is the code tested?**
20 pytest unit tests across three files: `test_database.py` (schema
init, CRUD operations, statistics aggregation), `test_detectors.py` (all
three detectors, with `psutil` calls monkeypatched for determinism), and
`test_collector.py` (Linux log-line parsing with temporary files). Every
test uses a temporary SQLite file via pytest's `tmp_path` fixture, so
tests never touch the real database.

**27. How did you test the port scan and process detectors without a real attack?**
By monkeypatching `psutil.net_connections` and `psutil.process_iter` to
return fake, controlled data (e.g. a fake remote IP touching 24 distinct
local ports, or a fake process named `mimikatz.exe`), so the detection
logic itself is verified deterministically without depending on the
host's actual network/process state.

**28. What design choice made the detectors easy to unit test?**
Every detector's constructor accepts optional threshold/window overrides
instead of only reading from global `Config`. Tests can instantiate a
detector with `threshold=5, window_seconds=120` explicitly, independent
of whatever the current `config.py` values happen to be.

**29. What type hints and docstring conventions did you follow?**
Full PEP 484 type hints on every function signature (including modern
`list[str]`/`dict[str, Any]` syntax, Python 3.10+), Google-style docstrings
with `Args:`/`Returns:` sections on every public method, and module-level
docstrings explaining each file's purpose at the top.

**30. How do you handle exceptions in the collector and detectors?**
Each `scan()`/`collect()` call is wrapped in try/except at the
orchestration layer (`LogCollectionService.run_once`,
`DetectionService.run_once`) so that one detector or collector raising an
unexpected exception logs it via `logger.exception(...)` and returns
gracefully, rather than crashing the entire background thread and silently
stopping all future detection.

**31. Why use dataclasses for `NormalizedLog`?**
Type safety, auto-generated `__init__`/`__repr__`, and a clear, self-
documenting schema definition in one place, with a `__post_init__`
validation hook that falls back to `"info"` severity if an invalid value
is passed — cheaper and clearer than manually writing an `__init__` with
validation logic.

**32. What would you refactor if you had more time?**
Extract the "insert alert if not already alerted recently" pattern
(duplicated between `FailedLoginDetector` and `PortScanDetector`) into a
shared helper method or base class, and add integration tests that spin up
the actual Flask test client against a temporary database.

---

## E. Security & Real-World Considerations

**33. What are the security limitations of this project as built?**
It's a monitoring tool, not a prevention tool — it detects and displays,
it doesn't block anything. The dashboard has no authentication (fine for
local/lab use, not for internet-facing deployment). Detection is signature/
threshold-based, not behavioral or ML-based, so it can be evaded by an
attacker who paces their attempts below the threshold or uses a name not
in the blacklist.

**34. How would you add authentication to the dashboard?**
Flask-Login or a simple session-based auth decorator on the blueprint's
routes, backed by a users table (out of scope for this project, but a
natural next step), or put it behind a reverse proxy (nginx) with HTTP
basic auth / SSO for a lab environment.

**35. Why does the Flask app run with `debug=False` by default?**
Debug mode enables the interactive debugger and auto-reloader, which is a
serious remote-code-execution risk if the dashboard is ever exposed beyond
localhost, and the reloader would also double-start the background
threads. It's controllable via the `MINI_SOC_DEBUG` environment variable
for local development only.

**36. What's the risk of the process blacklist approach in general?**
Blacklists only catch known bad names/strings — trivially evaded by
renaming a binary or obfuscating the command line. This project uses it
because it's simple and pedagogically clear, but production EDR tools use
behavioral detection, code signing verification, and hash-based
allowlisting instead.

**37. How do you handle log rotation (e.g. logrotate rotating auth.log nightly)?**
`BaseCollector._tail_new_lines()` detects when a file's size has shrunk
since the last read (a strong signal of rotation/truncation) and resets
the read offset to 0, so the collector picks back up from the start of the
new file instead of silently missing all events written since rotation.

**38. What permissions does this need to run, and why?**
Reading `/var/log/auth.log` typically requires root or membership in the
log-owning group (e.g. `adm` on Debian/Ubuntu) since it may contain
sensitive authentication data. Reading the full OS network connection
table via `psutil.net_connections()` may also require elevated privileges
on some platforms to see connections owned by other users. The app
degrades gracefully (logs a warning, returns empty results) if it lacks
these permissions rather than crashing.

**39. Is storing full command lines in the `processes` table a privacy/security concern?**
Potentially — command lines can contain secrets (e.g. a password passed as
a CLI argument). In a production system I'd redact known-sensitive
argument patterns before storage, and restrict database file permissions
tightly (this is already implicitly local-only via SQLite file
permissions, but that's worth calling out explicitly rather than assuming).

**40. How would you extend this to detect lateral movement or privilege escalation?**
Add detectors that watch for specific event patterns instead of simple
thresholds — e.g. a successful login immediately following several failed
attempts (successful brute-force), a user account added to an admin group
shortly after a suspicious process alert, or process-parent/child
relationship anomalies (e.g. `sshd` spawning an unexpected shell). These
would need richer event correlation than the current independent-detector
model supports, which is a natural motivation for a future "correlation
engine" component.

**41. Why SQLite and not PostgreSQL/MySQL for a "real" version of this?**
For a single-host portfolio project, SQLite has zero setup cost and is
perfectly adequate for this data volume. For a real multi-host deployment
I'd move to PostgreSQL (or a time-series-optimized store) for concurrent
write throughput across multiple collector instances and proper
network-accessible multi-client access, which SQLite isn't designed for.

**42. What's your approach to configuration secrets (e.g. if this needed an API key)?**
None are currently required, but the pattern is already established via
`os.environ.get(...)` in `config.py` for path/host/port overrides — I'd
extend the same pattern for secrets, reading them from environment
variables (or a `.env` file excluded from version control) rather than
hard-coding them.

**43. How would you containerize this?**
A Dockerfile installing `requirements.txt`, copying the app, and running
`python app.py`, with `MINI_SOC_AUTH_LOG`/`MINI_SOC_SYSLOG` mounted as
volumes pointing at the host's actual log files (or `sample_logs/` for a
self-contained demo container), and the SQLite `data/` directory mounted
as a volume for persistence across container restarts.

**44. What would break if two instances of this app ran against the same SQLite file?**
WAL mode handles multiple readers plus one writer well, but with two full
application instances both running collectors and detectors, you'd get
duplicate log ingestion (if both read the same log files) and duplicate
detection passes — this design assumes a single application instance per
monitored host, which is a reasonable assumption to state explicitly if
asked.

**45. Why is `psutil.net_connections()`-based port-scan detection unreliable against a fast `nmap` scan?**
Because it's a *periodic snapshot*, not a packet capture. `PortScanDetector`
only sees whatever's in the OS connection table at the instant it polls
(every 15s by default). A fast TCP connect scan against closed ports opens
and gets RST'd in well under a millisecond — that connection is gone from
the table long before the next poll, so it's simply never observed. I
confirmed this directly: `nmap -T4 -p 1-100 127.0.0.1` against closed local
ports produced zero alerts, while holding 25 real connections open for 20+
seconds (longer than one poll interval) reliably triggered the detector
every time. That's *why* `scripts/generate_demo_data.py` simulates a scan by
opening and holding loopback sockets rather than shelling out to `nmap` —
it needed to be deterministic for a demo, and polling-based detection is
fundamentally biased toward catching *sustained* connection activity, not
sub-second scans. A production version would need either a shorter poll
interval, a persistent packet-capture-based detector (e.g. via `scapy` or
kernel connection-tracking events), or both.

**46. What's the most significant bug you found and fixed while hardening this project, and how did you find it?**
A timezone bug in `LinuxCollector._parse_timestamp()`. Classic syslog/
auth.log timestamps (`Mon DD HH:MM:SS`) carry no timezone and are written
in the system's *local* time, but the original code did
`parsed.replace(tzinfo=timezone.utc)` — which labels a local timestamp as
UTC without converting it. On a system where local time isn't UTC (e.g.
`America/New_York`, UTC-4), every parsed log event ends up timestamped
several hours away from where it actually happened in UTC terms. Since
`FailedLoginDetector` compares log timestamps against a
`datetime.now(timezone.utc)`-based rolling window (120s by default), those
mislabeled timestamps fell completely outside the window and the detector
silently never fired — no exception, no error in the logs, it just never
alerted. I found it by actually exercising the full pipeline end-to-end
(writing synthetic attack logs and watching the dashboard) instead of
trusting that passing unit tests meant the feature worked; the unit tests
didn't catch it because they don't assert on the *parsed* timestamp value,
only on username/IP/severity. The fix uses `naive_dt.astimezone()`, which
Python interprets as "this naive datetime is in the system's local
timezone," then converts to true UTC with `.astimezone(timezone.utc)`. It's
a good example of why "the tests pass" and "the feature works" are
different claims, especially for anything involving timestamps and
timezones.
