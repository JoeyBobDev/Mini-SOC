# Mini SOC — 5-Minute Demo Script

Narration-only script (no voice recording needed — read this aloud or use
it as on-screen captions while you screen-record). Each section includes an
approximate timestamp and the exact commands to run.

Total runtime target: **~5 minutes**.

---

### [0:00 – 0:30] Introduction

> "Hi, I'm going to walk you through Mini SOC — a lightweight Security
> Operations Center dashboard I built from scratch in Python. It collects
> real operating system logs, detects three common attack patterns —
> brute-force logins, port scans, and suspicious processes — and displays
> everything on a live dashboard. No enterprise SIEM stack, no
> Elasticsearch — just Python, Flask, SQLite, and about a dozen focused
> modules."

*(Show the project folder structure in a code editor — collector/,
detectors/, dashboard/, database/, utils/.)*

---

### [0:30 – 1:15] Starting the Application

> "Let's start it up. I'll point it at a sample log directory so the demo
> doesn't require root access to real system logs."

```bash
MINI_SOC_DEMO=1 python app.py
```

> "Behind the scenes, this does three things: it initializes the SQLite
> database with three tables — logs, alerts, and processes — then starts
> two background threads: one polling the OS logs every 10 seconds, and
> one running the three detectors every 15 seconds. Then it starts the
> Flask dashboard on the main thread."

*(Open browser to http://127.0.0.1:5000)*

> "And here's the dashboard. Right now it's empty — no logs collected yet
> from our sample files. Let's fix that."

---

### [1:15 – 2:30] Simulating a Brute-Force Attack + Port Scan

> "In a second terminal, I'll run a script that drives the whole pipeline
> end to end: a few normal logins, 8 rapid failed login attempts from a
> single IP, and then a simulated port scan."

```bash
python scripts/generate_demo_data.py
```

*(Let it run — show the terminal output listing each failed attempt, then
the port-scan phase connecting to 25 ports.)*

> "This is writing realistic auth.log-formatted lines — the same format
> you'd see from real sshd — to our sample log file. Our Linux collector is
> tailing that file every 10 seconds and parsing each new line with regex
> patterns that extract the username, source IP, and event type. Then it
> opens 25 loopback connections and holds them open for 20 seconds — long
> enough for the port-scan detector, which polls `psutil.net_connections()`
> every 15 seconds, to reliably catch all of them in one snapshot. A fast
> `nmap` scan against closed ports can actually finish and disappear from
> the connection table between polls, so this script trades a 'more
> realistic-looking' scan for a demo that works every single time."

*(Switch back to dashboard, wait ~20-25 seconds, or refresh.)*

> "And there it is — the dashboard auto-refreshes every 5 seconds without a
> page reload. We can see the Total Logs counter climbing, a new
> 'failed_login' alert because we exceeded our threshold of 5 failed
> attempts within 2 minutes, and a 'port_scan' alert for 25+ distinct ports
> touched within 60 seconds — both severity high, with structured JSON
> details (usernames targeted, ports touched) in each alert."

*(Point to the Recent Alerts table and the Recent Logs table showing the
individual failed_login entries.)*

---

### [2:30 – 3:15] Demonstrating Suspicious Process Detection

> "Last detector: suspicious processes. This one scans all running
> processes every 15 seconds and checks their name against the blacklist
> (exact/`.exe` match) and their command line (word-boundary regex match) —
> things like mimikatz, netcat, ncat, psexec."

```bash
ncat -l 4444
```

*(Wait ~15 seconds, switch to dashboard.)*

> "There it is in the Suspicious Processes table — process name, PID, the
> user that ran it, and which blacklist rule matched. This blacklist lives
> entirely in config.yaml — no code changes needed to add or remove entries
> for your own environment."

---

### [3:15 – 4:15] Code Walkthrough Highlights

*(Briefly show config.py, then database/db_manager.py, then one detector.)*

> "A few design points worth calling out. First, everything is centrally
> configurable — thresholds, the blacklist, polling intervals, file paths
> — all in one config.py file, nothing hard-coded. Second, the database
> layer is thread-safe: the collector and detectors run in background
> threads while Flask serves requests, so I'm using SQLite's WAL mode plus
> a lock to keep that safe. Third, each detector is a small, independently
> testable class — I've got 20 unit tests covering the database layer, all
> three detectors, and the log parsing logic (including a regression test
> for a timezone bug I found and fixed — local syslog timestamps were being
> mislabeled as UTC instead of converted), using mocked psutil calls so
> tests never touch your real system."

```bash
pytest tests/ -v
```

*(Show the test output — 20 passed.)*

---

### [4:15 – 5:00] Wrap-Up

> "That's Mini SOC — a full collect, detect, and present pipeline for
> three common attack patterns, built with just Flask, SQLite, and psutil,
> in a modular codebase that's easy to extend. Thanks for watching."

*(End on the dashboard showing all three alert types populated.)*

---

## Pre-Recording Checklist

- [ ] `pip install -r requirements.txt` completed
- [ ] `ncat` installed (ships with `nmap`) for the suspicious-process demo
- [ ] `sample_logs/auth.log` and `sample_logs/syslog` exist (even empty —
      `generate_demo_data.py` truncates and rewrites them on every run)
- [ ] Two terminal windows arranged side-by-side (one running
      `MINI_SOC_DEMO=1 python app.py`, one for demo commands) plus a
      browser window
- [ ] Database cleared before the recording (`rm -f data/mini_soc.db*`) for
      a clean "0 logs" starting state
