# Mini SOC — Resume Bullet Points

A set of ready-to-use resume bullets describing this project, at different
lengths and with different emphases. Pick the ones that best match the role
you're applying for, and adjust specifics (metrics, tech stack) to match
your actual experience building it.

---

## Short version (1 bullet, general software/security role)

> Built Mini SOC, a full-stack Python security monitoring dashboard that
> collects and normalizes OS logs, detects brute-force logins/port scans/
> suspicious processes in real time, and visualizes alerts via a Flask +
> Bootstrap dashboard backed by SQLite.

---

## Standard version (2–3 bullets, cybersecurity-focused roles)

> - Designed and implemented **Mini SOC**, an end-to-end security
>   monitoring pipeline in Python that collects Windows Event Logs and
>   Linux auth.log/syslog data, normalizes events into a unified JSON
>   schema, and persists them to a thread-safe SQLite data layer.
> - Engineered three independent detection modules — brute-force login
>   detection (threshold/time-window based), port-scan detection (via live
>   OS connection-table analysis with `psutil`), and suspicious-process
>   detection (configurable blacklist matching) — with duplicate-alert
>   suppression logic to keep alert data actionable.
> - Built a live-updating Flask/Bootstrap dashboard (auto-refreshing via
>   JSON API polling) surfacing recent logs, alerts, and statistics;
>   validated the system with 20 automated unit tests covering the
>   database layer, detection logic, and log-parsing regex patterns.

---

## Detailed version (for a dedicated "Projects" resume section)

> **Mini SOC — Security Monitoring Dashboard** *(Python, Flask, SQLite, psutil, Bootstrap)*
> - Architected a modular, multi-threaded security monitoring application
>   simulating core SOC analyst workflows: log collection, normalization,
>   threat detection, and alert triage — without relying on third-party
>   SIEM infrastructure (no Elasticsearch/Kibana dependency).
> - Implemented cross-platform log collectors for Windows Event Log
>   (via pywin32) and Linux auth.log/syslog (via regex-based parsing with
>   stateful file-offset tracking to support incremental "tail -f"-style
>   ingestion and safe log-rotation handling).
> - Built three independently testable detection engines applying
>   configurable thresholds over rolling time windows to identify
>   brute-force login attempts, port-scanning behavior, and blacklisted
>   process execution, achieving sub-40-second end-to-end detection
>   latency from event occurrence to dashboard alert.
> - Designed a thread-safe SQLite data access layer (WAL mode + a
>   short-lived connection per operation) supporting concurrent writes from background
>   polling threads and concurrent reads from Flask request handlers
>   without data corruption.
> - Developed a live, auto-refreshing Bootstrap 5 dashboard with a JSON
>   REST API layer, displaying real-time statistics, recent logs, active
>   alerts, and flagged processes.
> - Authored 20 automated unit tests (pytest) with mocked system calls
>   (`psutil`) achieving deterministic, isolated test coverage of all
>   detection logic and log-parsing behavior.
> - Documented complete system architecture, module-level design
>   rationale, and a full setup/demo guide to support onboarding and
>   knowledge transfer.

---

## Skills/technology keyword list (for resume "Skills" section or ATS matching)

Python 3.10+ · Flask · SQLite · Object-Oriented Design · Threading /
Concurrency · Regular Expressions (Regex) · Log Parsing & Normalization ·
psutil · Windows Event Log (pywin32) · Linux Syslog/Auth Log Analysis ·
Intrusion Detection Concepts · Brute-Force Detection · Port Scan Detection ·
Blacklist-Based Process Monitoring · REST API Design · Bootstrap 5 ·
JavaScript (Fetch API / AJAX) · Unit Testing (pytest) · Mocking/Monkeypatching ·
Type Hints (PEP 484) · Modular Software Architecture · Technical
Documentation · Security Operations Center (SOC) Fundamentals

---

## LinkedIn "About" or portfolio one-liner

> I built Mini SOC — a lightweight security monitoring dashboard in Python
> that simulates real SOC analyst workflows (log collection, brute-force/
> port-scan/malicious-process detection, and live alerting) from scratch,
> without relying on enterprise SIEM tooling.

---

## Interview-ready 30-second verbal summary

> "I built a security monitoring dashboard called Mini SOC — it runs on a
> machine, tails the system's own logs, and detects three common attack
> patterns: brute-force login attempts, port scans, and known malicious
> process names, using configurable thresholds over rolling time windows.
> Everything's normalized into a common schema, stored in SQLite, and
> shown on a live Flask dashboard that auto-refreshes. I built it entirely
> in Python with a modular, testable architecture — no external SIEM
> infrastructure — and backed it with 20 unit tests covering the detection
> logic and log parsing."
