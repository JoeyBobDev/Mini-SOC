"""
app.py
======
Main entry point for Mini SOC - Security Monitoring Dashboard.

Responsibilities:
    1. Initialize the SQLite database (logs / alerts / processes tables).
    2. Start the log collection service in a background thread.
    3. Start the detection service (failed login / port scan / suspicious
       process) in a second background thread.
    4. Serve the Flask dashboard in the main thread.

Run with:
    python app.py
"""

from __future__ import annotations

import atexit
import threading

from flask import Flask

from collector.log_collector import LogCollectionService
from config import Config
from dashboard.routes import dashboard_bp
from database.db_manager import DatabaseManager
from detectors.detection_service import DetectionService
from utils.logger import get_logger

logger = get_logger(__name__)


def create_app(db_manager: DatabaseManager) -> Flask:
    """
    Application factory: build and configure the Flask app.

    Args:
        db_manager: Shared DatabaseManager instance used by all routes.

    Returns:
        A configured Flask application instance.
    """
    app = Flask(__name__, static_folder=None)
    app.config["DB_MANAGER"] = db_manager
    app.register_blueprint(dashboard_bp)
    return app


def start_background_services(
    db_manager: DatabaseManager,
) -> tuple[LogCollectionService, DetectionService]:
    """
    Start the log collector and detection service as daemon threads.

    Args:
        db_manager: Shared DatabaseManager instance.

    Returns:
        The (collection_service, detection_service) instances, so callers
        can call .stop() on them during shutdown.
    """
    collection_service = LogCollectionService(db_manager)
    detection_service = DetectionService(db_manager)

    collector_thread = threading.Thread(
        target=collection_service.run_forever,
        name="LogCollectorThread",
        daemon=True,
    )
    detector_thread = threading.Thread(
        target=detection_service.run_forever,
        name="DetectionServiceThread",
        daemon=True,
    )

    collector_thread.start()
    detector_thread.start()

    logger.info("Background services started (collector + detectors).")
    return collection_service, detection_service


def main() -> None:
    """Initialize services and run the Flask development server."""
    Config.ensure_directories()
    logger.info("Starting Mini SOC - Security Monitoring Dashboard")

    db_manager = DatabaseManager()
    collection_service, detection_service = start_background_services(db_manager)

    def _shutdown() -> None:
        logger.info("Shutting down Mini SOC background services...")
        collection_service.stop()
        detection_service.stop()

    atexit.register(_shutdown)

    app = create_app(db_manager)
    app.run(
        host=Config.DASHBOARD_HOST,
        port=Config.DASHBOARD_PORT,
        debug=Config.DASHBOARD_DEBUG,
        use_reloader=False,  # avoid double-starting background threads
    )


if __name__ == "__main__":
    main()
