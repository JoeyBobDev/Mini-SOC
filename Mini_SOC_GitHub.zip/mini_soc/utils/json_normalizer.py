"""
utils/json_normalizer.py
=========================
Defines the canonical normalized log record used throughout Mini SOC,
and helper functions to build/serialize it.

Every collector (Linux, Windows) must convert raw OS log entries into
this common schema before storing them in the database. This keeps the
detectors and dashboard completely decoupled from OS-specific log
formats.

Normalized schema:
{
    "timestamp":   ISO-8601 string,
    "hostname":    str,
    "event_type":  str   (e.g. "failed_login", "accepted_login",
                           "process_start", "generic"),
    "username":    str | None,
    "source_ip":   str | None,
    "message":     str,
    "severity":    str   ("info" | "low" | "medium" | "high" | "critical")
}
"""

from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass, asdict
from typing import Any, Optional


VALID_SEVERITIES = {"info", "low", "medium", "high", "critical"}


@dataclass
class NormalizedLog:
    """Canonical representation of a single log event."""

    timestamp: str
    hostname: str
    event_type: str
    username: Optional[str]
    source_ip: Optional[str]
    message: str
    severity: str = "info"

    def __post_init__(self) -> None:
        if self.severity not in VALID_SEVERITIES:
            self.severity = "info"

    def to_dict(self) -> dict[str, Any]:
        """Return the record as a plain dictionary."""
        return asdict(self)


def now_iso() -> str:
    """Return the current UTC time as an ISO-8601 string."""
    return _dt.datetime.now(_dt.timezone.utc).isoformat()


def build_normalized_log(
    hostname: str,
    event_type: str,
    message: str,
    username: Optional[str] = None,
    source_ip: Optional[str] = None,
    severity: str = "info",
    timestamp: Optional[str] = None,
) -> NormalizedLog:
    """
    Convenience factory for creating a :class:`NormalizedLog`.

    Args:
        hostname: Machine the event originated from.
        event_type: Categorized event type (e.g. "failed_login").
        message: Human-readable raw/summarized message.
        username: Username associated with the event, if any.
        source_ip: Source IP address associated with the event, if any.
        severity: One of "info", "low", "medium", "high", "critical".
        timestamp: ISO-8601 timestamp; defaults to now (UTC).

    Returns:
        A populated NormalizedLog instance.
    """
    return NormalizedLog(
        timestamp=timestamp or now_iso(),
        hostname=hostname,
        event_type=event_type,
        username=username,
        source_ip=source_ip,
        message=message,
        severity=severity,
    )
