"""
utils/logger.py
================
Centralized application logger for Mini SOC.

Every module in this project should obtain its logger via
``get_logger(__name__)`` instead of configuring ``logging`` itself.
This guarantees a single, consistent log format written to
``logs/application.log`` as well as to the console.

Supports log levels: DEBUG, INFO, WARNING, ERROR, CRITICAL.
Uses ``RotatingFileHandler`` to prevent unbounded log growth.
"""

from __future__ import annotations

import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

from config import Config

_LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

_configured: bool = False


def _configure_root_logger() -> None:
    """Configure the root 'mini_soc' logger exactly once (idempotent)."""
    global _configured
    if _configured:
        return

    Config.ensure_directories()

    # Ensure the log file's parent directory exists
    log_path = Path(Config.APP_LOG_FILE)
    log_path.parent.mkdir(parents=True, exist_ok=True)

    root_logger = logging.getLogger("mini_soc")
    root_logger.setLevel(getattr(logging, Config.APP_LOG_LEVEL, logging.INFO))
    root_logger.propagate = False

    # Avoid adding duplicate handlers if called again
    if root_logger.handlers:
        _configured = True
        return

    formatter = logging.Formatter(_LOG_FORMAT, datefmt=_DATE_FORMAT)

    # Rotating file handler: keeps logs/application.log from growing unbounded.
    # Max 5 MB per file, 3 backups kept.
    file_handler = RotatingFileHandler(
        Config.APP_LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=3
    )
    file_handler.setFormatter(formatter)
    root_logger.addHandler(file_handler)

    # Console handler for real-time visibility during development.
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)

    _configured = True


def get_logger(module_name: str) -> logging.Logger:
    """
    Return a namespaced logger that writes to logs/application.log.

    Args:
        module_name: Typically ``__name__`` of the calling module.

    Returns:
        A configured ``logging.Logger`` instance.
    """
    _configure_root_logger()
    return logging.getLogger(f"mini_soc.{module_name}")
