"""Utility package: application logging and JSON normalization helpers."""
