"""
config.py
=========
Central configuration for Mini SOC.

Loads settings from ``config.yaml`` (if present) and falls back to
sensible built-in defaults. Environment variables still override
individual values where supported.

Usage::

    from config import Config
    Config.FAILED_LOGIN_THRESHOLD
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, List


def _load_yaml() -> Dict[str, Any]:
    """Load config.yaml from the project root, returning an empty dict on failure."""
    yaml_path = Path(__file__).resolve().parent / "config.yaml"
    if not yaml_path.exists():
        return {}
    try:
        import yaml  # type: ignore

        with open(yaml_path, "r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh)
            return data if isinstance(data, dict) else {}
    except ImportError:
        # PyYAML not installed — parse a minimal subset manually or
        # just fall back to defaults.
        return _parse_yaml_fallback(yaml_path)
    except Exception:  # pylint: disable=broad-except
        return {}


def _parse_yaml_fallback(yaml_path: Path) -> Dict[str, Any]:
    """
    Ultra-minimal YAML parser for flat key-value pairs and simple lists.

    This lets the project work without PyYAML installed: we only need to
    parse the known config.yaml structure (nested dicts, scalar values,
    and simple ``- item`` lists).
    """
    result: Dict[str, Any] = {}
    try:
        with open(yaml_path, "r", encoding="utf-8") as fh:
            lines = fh.readlines()

        current_section: str | None = None
        current_list_key: str | None = None

        for raw_line in lines:
            stripped = raw_line.rstrip()
            # Skip blank lines and comments
            if not stripped or stripped.lstrip().startswith("#"):
                current_list_key = None
                continue

            indent = len(raw_line) - len(raw_line.lstrip())

            # List item under a key
            if stripped.lstrip().startswith("- "):
                if current_list_key:
                    full_key = (
                        f"{current_section}.{current_list_key}"
                        if current_section
                        else current_list_key
                    )
                    if full_key not in result:
                        result[full_key] = []
                    value = stripped.lstrip()[2:].strip().strip('"').strip("'")
                    result[full_key].append(value)
                continue

            # Key: value pair
            if ":" in stripped:
                key, _, value = stripped.partition(":")
                key = key.strip()
                value = value.strip().strip('"').strip("'")

                if indent == 0:
                    # Top-level key
                    if not value:
                        # Section header
                        current_section = key
                        current_list_key = None
                    else:
                        current_section = None
                        current_list_key = None
                        result[key] = _coerce(value)
                else:
                    # Nested key
                    full_key = f"{current_section}.{key}" if current_section else key
                    if not value:
                        # This key expects a list
                        current_list_key = key
                    else:
                        current_list_key = None
                        result[full_key] = _coerce(value)
    except Exception:  # pylint: disable=broad-except
        pass
    return result


def _coerce(value: str) -> Any:
    """Coerce a string value to int, float, bool, or None."""
    if value.lower() in ("true", "yes"):
        return True
    if value.lower() in ("false", "no"):
        return False
    if value.lower() in ("null", "none", "~"):
        return None
    try:
        return int(value)
    except ValueError:
        pass
    try:
        return float(value)
    except ValueError:
        pass
    return value


def _get(cfg: Dict[str, Any], dotted_key: str, default: Any = None) -> Any:
    """Retrieve a value from the flat or nested config dict by dotted key."""
    # Try flat key first (from fallback parser)
    if dotted_key in cfg:
        return cfg[dotted_key]
    # Try nested dict (from PyYAML)
    parts = dotted_key.split(".")
    node: Any = cfg
    for part in parts:
        if isinstance(node, dict) and part in node:
            node = node[part]
        else:
            return default
    return node


# Load config once at import time
_CFG = _load_yaml()


class Config:
    """Static configuration container for the Mini SOC application."""

    # ------------------------------------------------------------------
    # Base paths
    # ------------------------------------------------------------------
    BASE_DIR: Path = Path(__file__).resolve().parent
    LOGS_DIR: Path = BASE_DIR / "logs"
    DATA_DIR: Path = BASE_DIR / "data"
    SAMPLE_LOGS_DIR: Path = BASE_DIR / "sample_logs"

    # ------------------------------------------------------------------
    # Database
    # ------------------------------------------------------------------
    DATABASE_PATH: str = str(DATA_DIR / "mini_soc.db")

    # ------------------------------------------------------------------
    # Application logging (logs/application.log)
    # ------------------------------------------------------------------
    APP_LOG_FILE: str = str(
        BASE_DIR / _get(_CFG, "logging.file", "logs/application.log")
    )
    APP_LOG_LEVEL: str = str(_get(_CFG, "logging.level", "INFO")).upper()

    # ------------------------------------------------------------------
    # Source log files collected from the local operating system
    # ------------------------------------------------------------------
    # Environment variables override config.yaml, which overrides defaults.
    LINUX_AUTH_LOG_PATHS: List[str] = [
        p
        for p in [
            os.environ.get("MINI_SOC_AUTH_LOG"),
            *(_get(_CFG, "collector.linux_auth_log_paths", None) or []),
            "/var/log/auth.log",
            "/var/log/secure",
        ]
        if p
    ]
    # Deduplicate while preserving order
    LINUX_AUTH_LOG_PATHS = list(dict.fromkeys(LINUX_AUTH_LOG_PATHS))

    LINUX_SYSLOG_PATHS: List[str] = [
        p
        for p in [
            os.environ.get("MINI_SOC_SYSLOG"),
            *(_get(_CFG, "collector.linux_syslog_paths", None) or []),
            "/var/log/syslog",
            "/var/log/messages",
        ]
        if p
    ]
    LINUX_SYSLOG_PATHS = list(dict.fromkeys(LINUX_SYSLOG_PATHS))

    # Windows Event Log channels to read
    WINDOWS_EVENT_LOG_CHANNELS: List[str] = _get(
        _CFG, "collector.windows_event_log_channels", ["Security", "System"]
    )
    # Legacy single-channel attribute (kept for backward compat)
    WINDOWS_EVENT_LOG_CHANNEL: str = WINDOWS_EVENT_LOG_CHANNELS[0]

    # ------------------------------------------------------------------
    # Demo mode
    # ------------------------------------------------------------------
    DEMO_MODE: bool = (
        os.environ.get("MINI_SOC_DEMO", "").lower() in ("1", "true", "yes")
        or _get(_CFG, "demo_mode", False) is True
    )

    # ------------------------------------------------------------------
    # Collector behaviour
    # ------------------------------------------------------------------
    POLLING_INTERVAL_SECONDS: int = int(
        _get(_CFG, "collector.polling_interval_seconds", 10)
    )
    COLLECTOR_BATCH_SIZE: int = int(_get(_CFG, "collector.batch_size", 500))

    # ------------------------------------------------------------------
    # Detection thresholds
    # ------------------------------------------------------------------
    FAILED_LOGIN_THRESHOLD: int = int(
        _get(_CFG, "detection.failed_login_threshold", 5)
    )
    FAILED_LOGIN_WINDOW_SECONDS: int = int(
        _get(_CFG, "detection.failed_login_window_seconds", 120)
    )
    PORT_SCAN_PORT_THRESHOLD: int = int(
        _get(_CFG, "detection.port_scan_port_threshold", 20)
    )
    PORT_SCAN_WINDOW_SECONDS: int = int(
        _get(_CFG, "detection.port_scan_window_seconds", 60)
    )
    PROCESS_SCAN_INTERVAL_SECONDS: int = int(
        _get(_CFG, "detection.process_scan_interval_seconds", 15)
    )

    # ------------------------------------------------------------------
    # Configurable process blacklist
    # ------------------------------------------------------------------
    SUSPICIOUS_PROCESS_BLACKLIST: List[str] = _get(
        _CFG,
        "blacklist",
        [
            "mimikatz",
            "nc.exe",
            "ncat",
            "netcat",
            "hydra",
            "powershell",
            "powershell.exe",
            "cmd.exe",
            "psexec",
            "powersploit",
            "cobaltstrike",
            "meterpreter",
            "pwdump",
            "procdump",
        ],
    )

    # ------------------------------------------------------------------
    # Dashboard
    # ------------------------------------------------------------------
    DASHBOARD_HOST: str = os.environ.get(
        "MINI_SOC_HOST", str(_get(_CFG, "dashboard.host", "0.0.0.0"))
    )
    DASHBOARD_PORT: int = int(
        os.environ.get(
            "MINI_SOC_PORT", _get(_CFG, "dashboard.port", 5000)
        )
    )
    DASHBOARD_DEBUG: bool = (
        os.environ.get("MINI_SOC_DEBUG", "").lower() in ("true", "1", "yes")
        or _get(_CFG, "dashboard.debug", False) is True
    )
    DASHBOARD_REFRESH_INTERVAL: int = int(
        _get(_CFG, "dashboard.refresh_interval_seconds", 5)
    )
    RECENT_LOGS_LIMIT: int = int(
        _get(_CFG, "dashboard.recent_logs_limit", 50)
    )
    RECENT_ALERTS_LIMIT: int = int(
        _get(_CFG, "dashboard.recent_alerts_limit", 50)
    )

    @classmethod
    def ensure_directories(cls) -> None:
        """Create required directories (logs/, data/, sample_logs/) if missing."""
        cls.LOGS_DIR.mkdir(parents=True, exist_ok=True)
        cls.DATA_DIR.mkdir(parents=True, exist_ok=True)
        cls.SAMPLE_LOGS_DIR.mkdir(parents=True, exist_ok=True)
