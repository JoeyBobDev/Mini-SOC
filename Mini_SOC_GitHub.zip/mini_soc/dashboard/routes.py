"""
dashboard/routes.py
=====================
Flask blueprint exposing the Mini SOC dashboard.

Routes:
    GET /                 - Main HTML dashboard (server-rendered)
    GET /api/stats        - JSON statistics (for the stat cards)
    GET /api/logs         - JSON recent logs
    GET /api/alerts       - JSON recent alerts
    GET /api/processes    - JSON recent suspicious processes

The database connection is retrieved from ``current_app.config["DB_MANAGER"]``,
which is wired up in ``app.py``. This keeps the blueprint free of any
direct dependency on how the app is constructed, making it easy to
unit test in isolation.
"""

from __future__ import annotations

from flask import Blueprint, current_app, jsonify, render_template

from config import Config
from database.db_manager import DatabaseManager
from utils.logger import get_logger

logger = get_logger(__name__)

dashboard_bp = Blueprint(
    "dashboard", __name__, template_folder="templates", static_folder="static"
)


def _get_db() -> DatabaseManager:
    """Fetch the shared DatabaseManager instance from the Flask app config."""
    return current_app.config["DB_MANAGER"]


@dashboard_bp.route("/", methods=["GET"])
def index():
    """Render the main dashboard page with server-side data."""
    db = _get_db()
    try:
        stats = db.get_statistics()
        recent_logs = db.get_recent_logs(limit=Config.RECENT_LOGS_LIMIT)
        recent_alerts = db.get_recent_alerts(limit=Config.RECENT_ALERTS_LIMIT)
        suspicious_processes = db.get_recent_suspicious_processes(limit=20)
    except Exception:  # pylint: disable=broad-except
        logger.exception("Failed to load dashboard data.")
        stats = {
            "total_logs": 0,
            "failed_login_alerts": 0,
            "port_scan_alerts": 0,
            "suspicious_processes": 0,
            "total_alerts": 0,
        }
        recent_logs, recent_alerts, suspicious_processes = [], [], []

    return render_template(
        "dashboard.html",
        stats=stats,
        logs=recent_logs,
        alerts=recent_alerts,
        processes=suspicious_processes,
        refresh_interval=Config.DASHBOARD_REFRESH_INTERVAL,
    )


@dashboard_bp.route("/api/stats", methods=["GET"])
def api_stats():
    """Return dashboard statistics as JSON."""
    db = _get_db()
    return jsonify(db.get_statistics())


@dashboard_bp.route("/api/logs", methods=["GET"])
def api_logs():
    """Return the most recent logs as JSON."""
    db = _get_db()
    return jsonify(db.get_recent_logs(limit=Config.RECENT_LOGS_LIMIT))


@dashboard_bp.route("/api/alerts", methods=["GET"])
def api_alerts():
    """Return the most recent alerts as JSON."""
    db = _get_db()
    return jsonify(db.get_recent_alerts(limit=Config.RECENT_ALERTS_LIMIT))


@dashboard_bp.route("/api/processes", methods=["GET"])
def api_processes():
    """Return the most recent suspicious processes as JSON."""
    db = _get_db()
    return jsonify(db.get_recent_suspicious_processes(limit=20))
