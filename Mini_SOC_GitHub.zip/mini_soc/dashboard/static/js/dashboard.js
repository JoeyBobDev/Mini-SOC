/**
 * dashboard.js
 * ============
 * Auto-refresh engine for the Mini SOC dashboard.
 *
 * Polls the JSON API endpoints every REFRESH_INTERVAL_MS (default: 5s,
 * configurable from config.yaml via the server-side template) and
 * updates stat cards, tables, and badge counts in place using AJAX,
 * so the analyst never has to manually reload the page.
 */

// Refresh interval is injected from the server template; fall back to 5s
const REFRESH_INTERVAL_MS = window.SOC_REFRESH_INTERVAL || 5000;

/**
 * Escape HTML special characters to prevent XSS.
 * @param {*} value - Value to escape.
 * @returns {string} Escaped string, or "-" for null/undefined.
 */
function escapeHtml(value) {
    if (value === null || value === undefined) return "-";
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}

/**
 * Format a snake_case field name (as stored in the database) into a
 * human-readable label, e.g. "source_ip" -> "Source IP".
 * @param {string} key - The raw field name.
 * @returns {string} Display label.
 */
function formatFieldLabel(key) {
    const upper = new Set(["ip", "pid", "id"]);
    return key
        .split("_")
        .map((word) => (upper.has(word) ? word.toUpperCase() : word.charAt(0).toUpperCase() + word.slice(1)))
        .join(" ");
}

/**
 * Render a single field's value for the detail modal. The alerts table's
 * `details` column is a JSON string, so pretty-print it if parseable.
 * @param {string} key - The field name.
 * @param {*} value - The raw value from the record.
 * @returns {string} Display text.
 */
function formatFieldValue(key, value) {
    if (value === null || value === undefined || value === "") return "—";
    if (key === "details" && typeof value === "string") {
        try {
            return JSON.stringify(JSON.parse(value), null, 2);
        } catch (err) {
            return value;
        }
    }
    return String(value);
}

// Field keys rendered as a <pre> block (long/structured text) rather than
// a single-line value in the detail modal.
const DETAIL_PRE_FIELDS = new Set(["message", "description", "details", "command_line"]);

/**
 * Populate and show the shared detail modal for a clicked table row.
 * @param {string} type - "log" | "alert" | "process".
 * @param {object} record - The full record (all DB columns) for that row.
 */
function openDetailModal(type, record) {
    const titles = { log: "Log Details", alert: "Alert Details", process: "Process Details" };
    const titleEl = document.getElementById("detailModalLabel");
    const bodyEl = document.getElementById("detailModalBody");
    if (!titleEl || !bodyEl) return;

    titleEl.textContent = titles[type] || "Details";
    bodyEl.innerHTML = "";

    Object.entries(record).forEach(([key, value]) => {
        const tr = document.createElement("tr");

        const th = document.createElement("th");
        th.scope = "row";
        th.className = "detail-label text-nowrap";
        th.textContent = formatFieldLabel(key);

        const td = document.createElement("td");
        td.className = "detail-value";
        const text = formatFieldValue(key, value);
        if (DETAIL_PRE_FIELDS.has(key)) {
            const pre = document.createElement("pre");
            pre.className = "detail-pre mb-0";
            pre.textContent = text;
            td.appendChild(pre);
        } else {
            td.textContent = text;
        }

        tr.appendChild(th);
        tr.appendChild(td);
        bodyEl.appendChild(tr);
    });

    const modalEl = document.getElementById("detailModal");
    if (modalEl && window.bootstrap) {
        window.bootstrap.Modal.getOrCreateInstance(modalEl).show();
    }
}

// Event delegation: works for both server-rendered rows (present on page
// load) and AJAX-refreshed rows (re-created every refresh cycle), since
// the listener is attached once to a static ancestor.
document.addEventListener("click", (evt) => {
    const row = evt.target.closest("tr[data-record]");
    if (!row) return;
    try {
        openDetailModal(row.dataset.type, JSON.parse(row.dataset.record));
    } catch (err) {
        console.error("Failed to parse row detail data:", err);
    }
});

/**
 * Attach `data-type`/`data-record` to each freshly-rendered row so it's
 * clickable, mirroring the attributes the server template sets on load.
 * @param {HTMLElement} tbody - The table body that was just re-rendered.
 * @param {string} type - "log" | "alert" | "process".
 * @param {object[]} records - The records rendered, in the same order as the rows.
 */
function attachRowRecords(tbody, type, records) {
    Array.from(tbody.children).forEach((tr, i) => {
        if (!records[i]) return;
        tr.dataset.type = type;
        tr.dataset.record = JSON.stringify(records[i]);
    });
}

/**
 * Get the CSS class for an event type badge.
 * @param {string} eventType - The event type string.
 * @returns {string} CSS class name.
 */
function eventBadgeClass(eventType) {
    const type = String(eventType || "").toLowerCase();
    if (type === "failed_login") return "event-failed_login";
    if (type === "accepted_login") return "event-accepted_login";
    if (type === "account_lockout") return "event-account_lockout";
    return "event-generic";
}

/**
 * Animate a stat value element when it changes.
 * @param {HTMLElement} el - The stat value DOM element.
 * @param {number|string} newValue - The new value to display.
 */
function updateStat(el, newValue) {
    if (!el) return;
    const oldValue = el.textContent.trim();
    const newStr = String(newValue);
    if (oldValue !== newStr) {
        el.textContent = newStr;
        el.classList.remove("stat-updated");
        // Force reflow to restart animation
        void el.offsetWidth;
        el.classList.add("stat-updated");
    }
}

/**
 * Refresh the stat cards via the /api/stats endpoint.
 */
async function refreshStats() {
    try {
        const res = await fetch("/api/stats");
        if (!res.ok) return;
        const stats = await res.json();
        updateStat(document.getElementById("stat-total-logs"), stats.total_logs);
        updateStat(document.getElementById("stat-total-alerts"), stats.total_alerts);
        updateStat(document.getElementById("stat-failed-login"), stats.failed_login_alerts);
        updateStat(document.getElementById("stat-port-scan"), stats.port_scan_alerts);
        updateStat(document.getElementById("stat-processes"), stats.suspicious_processes);
    } catch (err) {
        console.error("Failed to refresh stats:", err);
    }
}

/**
 * Refresh the Recent Alerts table.
 */
async function refreshAlerts() {
    try {
        const res = await fetch("/api/alerts");
        if (!res.ok) return;
        const alerts = await res.json();
        const tbody = document.querySelector("#alerts-table tbody");
        const badge = document.getElementById("alerts-count-badge");

        if (badge) badge.textContent = alerts.length;

        if (!alerts.length) {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted py-4">No alerts yet.</td></tr>';
            return;
        }
        tbody.innerHTML = alerts.map((a) => `
            <tr>
                <td class="text-nowrap small">${escapeHtml(a.timestamp)}</td>
                <td><span class="badge alert-type-badge">${escapeHtml(a.alert_type)}</span></td>
                <td><span class="badge severity-${escapeHtml(a.severity)}">${escapeHtml(a.severity)}</span></td>
                <td class="small">${escapeHtml(a.source_ip || a.username)}</td>
                <td class="small desc-cell">${escapeHtml(a.description)}</td>
            </tr>
        `).join("");
        attachRowRecords(tbody, "alert", alerts);
    } catch (err) {
        console.error("Failed to refresh alerts:", err);
    }
}

/**
 * Refresh the Recent Logs table.
 */
async function refreshLogs() {
    try {
        const res = await fetch("/api/logs");
        if (!res.ok) return;
        const logs = await res.json();
        const tbody = document.querySelector("#logs-table tbody");
        const badge = document.getElementById("logs-count-badge");

        if (badge) badge.textContent = logs.length;

        if (!logs.length) {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted py-4">No logs collected yet.</td></tr>';
            return;
        }
        tbody.innerHTML = logs.map((l) => `
            <tr>
                <td class="text-nowrap small">${escapeHtml(l.timestamp)}</td>
                <td><span class="badge event-type-badge ${eventBadgeClass(l.event_type)}">${escapeHtml(l.event_type)}</span></td>
                <td class="small">${escapeHtml(l.username)}</td>
                <td class="small">${escapeHtml(l.source_ip)}</td>
                <td class="small desc-cell">${escapeHtml(l.message)}</td>
            </tr>
        `).join("");
        attachRowRecords(tbody, "log", logs);
    } catch (err) {
        console.error("Failed to refresh logs:", err);
    }
}

/**
 * Refresh the Suspicious Processes table.
 */
async function refreshProcesses() {
    try {
        const res = await fetch("/api/processes");
        if (!res.ok) return;
        const processes = await res.json();
        const tbody = document.querySelector("#processes-table tbody");
        const badge = document.getElementById("processes-count-badge");

        if (badge) badge.textContent = processes.length;

        if (!processes.length) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted py-4">No suspicious processes detected.</td></tr>';
            return;
        }
        tbody.innerHTML = processes.map((p) => `
            <tr>
                <td class="text-nowrap small">${escapeHtml(p.timestamp)}</td>
                <td class="small">${escapeHtml(p.pid)}</td>
                <td class="small fw-semibold text-warning">${escapeHtml(p.process_name)}</td>
                <td class="small">${escapeHtml(p.username)}</td>
                <td><span class="badge bg-danger">${escapeHtml(p.matched_rule)}</span></td>
                <td class="small desc-cell">${escapeHtml(p.command_line)}</td>
            </tr>
        `).join("");
        attachRowRecords(tbody, "process", processes);
    } catch (err) {
        console.error("Failed to refresh processes:", err);
    }
}

/**
 * Refresh all dashboard sections.
 */
function refreshAll() {
    refreshStats();
    refreshAlerts();
    refreshLogs();
    refreshProcesses();
}

// Start the auto-refresh loop
setInterval(refreshAll, REFRESH_INTERVAL_MS);
console.log(`[Mini SOC] Dashboard auto-refresh active (every ${REFRESH_INTERVAL_MS / 1000}s)`);
