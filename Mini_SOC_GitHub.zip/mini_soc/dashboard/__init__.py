"""Dashboard package: Flask blueprint serving the Mini SOC web UI."""
