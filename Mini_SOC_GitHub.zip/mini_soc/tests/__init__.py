"""Test package for Mini SOC."""
