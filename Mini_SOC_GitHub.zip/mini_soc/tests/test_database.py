"""
tests/test_database.py
========================
Unit tests for database/db_manager.py using a temporary SQLite file
per test (via pytest's tmp_path fixture) so tests never touch the
real mini_soc.db.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from database.db_manager import DatabaseManager  # noqa: E402
from utils.json_normalizer import now_iso  # noqa: E402


def make_db(tmp_path: Path) -> DatabaseManager:
    return DatabaseManager(db_path=str(tmp_path / "test_mini_soc.db"))


def test_schema_initializes(tmp_path):
    db = make_db(tmp_path)
    # If schema init failed, get_statistics() would raise.
    stats = db.get_statistics()
    assert stats["total_logs"] == 0
    assert stats["total_alerts"] == 0


def test_insert_and_fetch_log(tmp_path):
    db = make_db(tmp_path)
    log_id = db.insert_log(
        timestamp=now_iso(),
        hostname="test-host",
        event_type="failed_login",
        message="Failed password for root from 1.2.3.4 port 22 ssh2",
        username="root",
        source_ip="1.2.3.4",
        severity="medium",
    )
    assert log_id > 0

    logs = db.get_recent_logs(limit=10)
    assert len(logs) == 1
    assert logs[0]["event_type"] == "failed_login"
    assert logs[0]["source_ip"] == "1.2.3.4"
    assert db.count_logs() == 1


def test_insert_and_fetch_alert(tmp_path):
    db = make_db(tmp_path)
    alert_id = db.insert_alert(
        timestamp=now_iso(),
        alert_type="failed_login",
        description="5 failed logins from 1.2.3.4",
        severity="high",
        source_ip="1.2.3.4",
        details={"attempt_count": 5},
    )
    assert alert_id > 0

    alerts = db.get_recent_alerts(limit=10)
    assert len(alerts) == 1
    assert alerts[0]["alert_type"] == "failed_login"
    assert db.count_alerts_by_type("failed_login") == 1
    assert db.count_alerts_by_type("port_scan") == 0


def test_alert_exists_recently(tmp_path):
    db = make_db(tmp_path)
    since = now_iso()
    assert db.alert_exists_recently("failed_login", "1.2.3.4", since) is False

    db.insert_alert(
        timestamp=now_iso(),
        alert_type="failed_login",
        description="test",
        source_ip="1.2.3.4",
    )
    assert db.alert_exists_recently("failed_login", "1.2.3.4", since) is True


def test_insert_and_fetch_process(tmp_path):
    db = make_db(tmp_path)
    db.insert_process(
        timestamp=now_iso(),
        hostname="test-host",
        pid=1234,
        process_name="ncat",
        username="root",
        command_line="ncat -l 4444",
        is_suspicious=True,
        matched_rule="ncat",
    )
    processes = db.get_recent_suspicious_processes(limit=10)
    assert len(processes) == 1
    assert processes[0]["process_name"] == "ncat"
    assert db.count_suspicious_processes() == 1


def test_statistics_aggregate_correctly(tmp_path):
    db = make_db(tmp_path)
    db.insert_log(
        timestamp=now_iso(), hostname="h", event_type="failed_login", message="m"
    )
    db.insert_alert(
        timestamp=now_iso(), alert_type="failed_login", description="d"
    )
    db.insert_alert(
        timestamp=now_iso(), alert_type="port_scan", description="d"
    )
    db.insert_process(
        timestamp=now_iso(),
        hostname="h",
        pid=1,
        process_name="mimikatz.exe",
        is_suspicious=True,
    )

    stats = db.get_statistics()
    assert stats["total_logs"] == 1
    assert stats["failed_login_alerts"] == 1
    assert stats["port_scan_alerts"] == 1
    assert stats["suspicious_processes"] == 1
    assert stats["total_alerts"] == 2
