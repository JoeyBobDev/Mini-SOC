"""
tests/test_collector.py
=========================
Unit tests for the Linux log collector and the JSON normalizer.

Uses a temporary auth.log/syslog file so tests never depend on the
real host's /var/log contents.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from collector.linux_collector import LinuxCollector  # noqa: E402
from utils.json_normalizer import build_normalized_log  # noqa: E402


def test_build_normalized_log_defaults():
    log = build_normalized_log(
        hostname="host1", event_type="generic", message="hello"
    )
    assert log.hostname == "host1"
    assert log.event_type == "generic"
    assert log.severity == "info"
    assert log.username is None
    assert log.source_ip is None


def test_build_normalized_log_invalid_severity_falls_back_to_info():
    log = build_normalized_log(
        hostname="host1", event_type="generic", message="hello", severity="not-a-real-severity"
    )
    assert log.severity == "info"


def _make_collector_with_paths(tmp_path: Path) -> tuple[LinuxCollector, Path, Path]:
    auth_log = tmp_path / "auth.log"
    syslog = tmp_path / "syslog"
    auth_log.write_text("")
    syslog.write_text("")

    collector = LinuxCollector.__new__(LinuxCollector)  # bypass __init__ path resolution
    from collector.base_collector import BaseCollector

    BaseCollector.__init__(collector)
    collector.hostname = "test-host"
    collector.auth_log_path = str(auth_log)
    collector.syslog_path = str(syslog)
    # Set the new journald-related attributes that __init__ would normally set
    collector._use_journald_auth = False
    collector._journald_last_cursor = None
    return collector, auth_log, syslog


def test_linux_collector_parses_failed_login(tmp_path):
    collector, auth_log, _ = _make_collector_with_paths(tmp_path)

    auth_log.write_text(
        "Jan 10 03:14:15 web01 sshd[1234]: Failed password for invalid user "
        "admin from 203.0.113.5 port 51514 ssh2\n"
    )

    results = collector.collect()
    failed_logins = [r for r in results if r.event_type == "failed_login"]
    assert len(failed_logins) == 1
    assert failed_logins[0].username == "admin"
    assert failed_logins[0].source_ip == "203.0.113.5"
    assert failed_logins[0].severity == "medium"


def test_linux_collector_parses_accepted_login(tmp_path):
    collector, auth_log, _ = _make_collector_with_paths(tmp_path)

    auth_log.write_text(
        "Jan 10 03:15:02 web01 sshd[1234]: Accepted password for root "
        "from 203.0.113.5 port 51520 ssh2\n"
    )

    results = collector.collect()
    accepted = [r for r in results if r.event_type == "accepted_login"]
    assert len(accepted) == 1
    assert accepted[0].username == "root"


def test_linux_collector_only_reads_new_lines(tmp_path):
    collector, auth_log, _ = _make_collector_with_paths(tmp_path)

    auth_log.write_text(
        "Jan 10 03:14:15 web01 sshd[1234]: Failed password for invalid user "
        "admin from 203.0.113.5 port 51514 ssh2\n"
    )
    first_pass = collector.collect()
    assert len(first_pass) == 1

    # No new lines appended -> second collect() should return nothing new.
    second_pass = collector.collect()
    assert len(second_pass) == 0

    # Append a new line -> should be picked up.
    with open(auth_log, "a", encoding="utf-8") as handle:
        handle.write(
            "Jan 10 03:16:00 web01 sshd[1234]: Failed password for invalid user "
            "test from 203.0.113.5 port 51999 ssh2\n"
        )
    third_pass = collector.collect()
    assert len(third_pass) == 1


def test_parsed_timestamp_is_converted_from_local_to_utc(tmp_path):
    """
    Regression test: classic syslog timestamps ('Mon DD HH:MM:SS') carry no
    timezone and are written in the system's local time. The parser must
    convert that local time to true UTC, not merely relabel it as UTC —
    otherwise, on any host whose local timezone isn't UTC, every parsed
    event drifts by the local UTC offset and can fall outside detectors'
    rolling time windows, silently breaking alerting (see docs/INTERVIEW_QA
    Q46 for the full story of this bug).
    """
    import datetime as dt

    collector, _, _ = _make_collector_with_paths(tmp_path)

    now_local = dt.datetime.now()
    month = now_local.strftime("%b")
    day = str(now_local.day)
    time_str = now_local.strftime("%H:%M:%S")

    parsed_iso = collector._parse_timestamp(month, day, time_str)
    parsed_utc = dt.datetime.fromisoformat(parsed_iso)

    expected_utc = now_local.astimezone(dt.timezone.utc)

    assert abs((parsed_utc - expected_utc).total_seconds()) < 2
