"""
tests/test_detectors.py
=========================
Unit tests for the three detectors: FailedLoginDetector,
PortScanDetector, and ProcessDetector.

External dependencies (psutil) are monkeypatched so tests are
deterministic and do not depend on the actual host's running
processes or network connections.
"""

import sys
from collections import namedtuple
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from database.db_manager import DatabaseManager  # noqa: E402
from detectors.failed_login_detector import FailedLoginDetector  # noqa: E402
from detectors.port_scan_detector import PortScanDetector  # noqa: E402
from detectors.process_detector import ProcessDetector  # noqa: E402
from utils.json_normalizer import now_iso  # noqa: E402


def make_db(tmp_path: Path) -> DatabaseManager:
    return DatabaseManager(db_path=str(tmp_path / "test_mini_soc.db"))


# ----------------------------------------------------------------------
# FailedLoginDetector
# ----------------------------------------------------------------------
def test_failed_login_detector_raises_alert_at_threshold(tmp_path):
    db = make_db(tmp_path)
    detector = FailedLoginDetector(db, threshold=5, window_seconds=120)

    for _ in range(5):
        db.insert_log(
            timestamp=now_iso(),
            hostname="host",
            event_type="failed_login",
            message="Failed password for root from 9.9.9.9 port 22 ssh2",
            username="root",
            source_ip="9.9.9.9",
            severity="medium",
        )

    alerts_raised = detector.scan()
    assert alerts_raised == 1
    alerts = db.get_recent_alerts()
    assert alerts[0]["alert_type"] == "failed_login"
    assert alerts[0]["source_ip"] == "9.9.9.9"


def test_failed_login_detector_does_not_alert_below_threshold(tmp_path):
    db = make_db(tmp_path)
    detector = FailedLoginDetector(db, threshold=5, window_seconds=120)

    for _ in range(3):
        db.insert_log(
            timestamp=now_iso(),
            hostname="host",
            event_type="failed_login",
            message="Failed password for root from 9.9.9.9 port 22 ssh2",
            username="root",
            source_ip="9.9.9.9",
        )

    assert detector.scan() == 0


def test_failed_login_detector_does_not_duplicate_alerts(tmp_path):
    db = make_db(tmp_path)
    detector = FailedLoginDetector(db, threshold=5, window_seconds=120)

    for _ in range(5):
        db.insert_log(
            timestamp=now_iso(),
            hostname="host",
            event_type="failed_login",
            message="Failed password for root from 9.9.9.9 port 22 ssh2",
            username="root",
            source_ip="9.9.9.9",
        )

    assert detector.scan() == 1
    # Running again immediately should not raise a second, duplicate alert.
    assert detector.scan() == 0


# ----------------------------------------------------------------------
# PortScanDetector
# ----------------------------------------------------------------------
FakeAddr = namedtuple("FakeAddr", ["ip", "port"])
FakeConn = namedtuple("FakeConn", ["laddr", "raddr"])


def test_port_scan_detector_raises_alert_at_threshold(tmp_path, monkeypatch):
    db = make_db(tmp_path)
    detector = PortScanDetector(db, port_threshold=20, window_seconds=60)

    fake_connections = [
        FakeConn(laddr=FakeAddr("0.0.0.0", port), raddr=FakeAddr("6.6.6.6", 54321))
        for port in range(1, 25)  # 24 distinct local ports
    ]

    monkeypatch.setattr(
        "detectors.port_scan_detector.psutil.net_connections",
        lambda kind="inet": fake_connections,
    )

    alerts_raised = detector.scan()
    assert alerts_raised == 1
    alerts = db.get_recent_alerts()
    assert alerts[0]["alert_type"] == "port_scan"
    assert alerts[0]["source_ip"] == "6.6.6.6"


def test_port_scan_detector_below_threshold_no_alert(tmp_path, monkeypatch):
    db = make_db(tmp_path)
    detector = PortScanDetector(db, port_threshold=20, window_seconds=60)

    fake_connections = [
        FakeConn(laddr=FakeAddr("0.0.0.0", port), raddr=FakeAddr("6.6.6.6", 54321))
        for port in range(1, 5)  # only 4 distinct local ports
    ]
    monkeypatch.setattr(
        "detectors.port_scan_detector.psutil.net_connections",
        lambda kind="inet": fake_connections,
    )

    assert detector.scan() == 0


# ----------------------------------------------------------------------
# ProcessDetector
# ----------------------------------------------------------------------
class FakeProcess:
    """Mimics the subset of psutil.Process used by ProcessDetector."""

    def __init__(self, pid, name, cmdline, username="testuser"):
        self.info = {
            "pid": pid,
            "name": name,
            "cmdline": cmdline,
            "username": username,
        }


def test_process_detector_flags_blacklisted_process(tmp_path, monkeypatch):
    db = make_db(tmp_path)
    detector = ProcessDetector(db, blacklist=["mimikatz", "ncat"])

    fake_processes = [
        FakeProcess(pid=100, name="bash", cmdline=["bash"]),
        FakeProcess(pid=200, name="mimikatz.exe", cmdline=["mimikatz.exe", "privilege::debug"]),
    ]
    monkeypatch.setattr(
        "detectors.process_detector.psutil.process_iter",
        lambda attrs=None: fake_processes,
    )

    alerts_raised = detector.scan()
    assert alerts_raised == 1

    processes = db.get_recent_suspicious_processes()
    assert len(processes) == 1
    assert processes[0]["pid"] == 200
    assert processes[0]["matched_rule"] == "mimikatz"


def test_process_detector_does_not_reflag_same_pid(tmp_path, monkeypatch):
    db = make_db(tmp_path)
    detector = ProcessDetector(db, blacklist=["ncat"])

    fake_processes = [FakeProcess(pid=300, name="ncat", cmdline=["ncat", "-l", "4444"])]
    monkeypatch.setattr(
        "detectors.process_detector.psutil.process_iter",
        lambda attrs=None: fake_processes,
    )

    assert detector.scan() == 1
    assert detector.scan() == 0  # same PID still running, no duplicate alert


def test_process_detector_ignores_clean_processes(tmp_path, monkeypatch):
    db = make_db(tmp_path)
    detector = ProcessDetector(db, blacklist=["mimikatz"])

    fake_processes = [
        FakeProcess(pid=1, name="init", cmdline=["init"]),
        FakeProcess(pid=2, name="sshd", cmdline=["/usr/sbin/sshd", "-D"]),
    ]
    monkeypatch.setattr(
        "detectors.process_detector.psutil.process_iter",
        lambda attrs=None: fake_processes,
    )

    assert detector.scan() == 0
    assert db.count_suspicious_processes() == 0
