"""
scripts/generate_demo_data.py
===============================
Generates a realistic, reproducible demo scenario for Mini SOC.

This script writes synthetic log lines to ``sample_logs/auth.log`` and
``sample_logs/syslog`` in the exact format the real ``LinuxCollector``
parses, and opens a burst of loopback TCP connections to exercise the
port-scan detector. It deliberately does **not** write to the database
directly — every event flows through the same collection/detection
pipeline a real attack would, so running this script is a faithful
end-to-end test of the whole application, not a shortcut around it.

Run ``python app.py`` in one terminal *first*, then this script in a
second terminal. Within one collector poll (default 10s) and one
detection poll (default 15s), the dashboard will show:

    - New rows in Recent Logs (normal + failed logins)
    - A "failed_login" alert (brute-force from a single IP)
    - A "port_scan" alert (one IP touching 20+ distinct ports)

Usage::

    python scripts/generate_demo_data.py
"""

from __future__ import annotations

import datetime
import random
import socket
import sys
import time
from pathlib import Path

# Ensure the project root is on sys.path so imports work when running
# this script directly (e.g. `python scripts/generate_demo_data.py`).
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from config import Config  # noqa: E402

SAMPLE_LOGS_DIR = Config.SAMPLE_LOGS_DIR
AUTH_LOG = SAMPLE_LOGS_DIR / "auth.log"
SYSLOG = SAMPLE_LOGS_DIR / "syslog"

HOSTNAME = "mini-soc-demo"
ATTACKER_IPS = ["203.0.113.77", "203.0.113.88"]
NORMAL_IPS = ["198.51.100.10", "198.51.100.11", "192.0.2.55"]
USERNAMES = ["root", "admin", "administrator", "ubuntu", "test"]

# Port-scan simulation: how many distinct loopback ports to touch and how
# long to hold the connections open. Held connections (rather than a fast
# nmap-style scan) are what make this demo deterministic: PortScanDetector
# only sees whatever psutil.net_connections() reports at the moment it
# polls (every PROCESS_SCAN_INTERVAL_SECONDS), so a connection that opens
# and closes in milliseconds can easily fall between polls and never be
# observed. Holding connections open for longer than one poll interval
# guarantees the detector's snapshot will catch them.
PORT_SCAN_PORT_COUNT = 25
PORT_SCAN_HOLD_SECONDS = 20


def _reset_sample_logs() -> None:
    """Truncate the demo log files so each run starts from a clean, known state."""
    SAMPLE_LOGS_DIR.mkdir(parents=True, exist_ok=True)
    AUTH_LOG.write_text("")
    SYSLOG.write_text("")


def _syslog_timestamp() -> str:
    """Return a timestamp formatted like classic syslog: 'Mon DD HH:MM:SS'."""
    return datetime.datetime.now().strftime("%b %d %H:%M:%S")


def _write_auth_line(line: str) -> None:
    """Append a line to the sample auth.log file."""
    with open(AUTH_LOG, "a", encoding="utf-8") as handle:
        handle.write(line + "\n")


def _write_syslog_line(line: str) -> None:
    """Append a line to the sample syslog file."""
    with open(SYSLOG, "a", encoding="utf-8") as handle:
        handle.write(line + "\n")


def simulate_normal_traffic(count: int = 5) -> None:
    """Write a handful of benign login/system events."""
    print(f"[demo] Writing {count} normal (benign) log lines...")
    for _ in range(count):
        ts = _syslog_timestamp()
        ip = random.choice(NORMAL_IPS)
        user = random.choice(USERNAMES)
        port = random.randint(40000, 60000)
        pid = random.randint(1000, 9999)

        _write_auth_line(
            f"{ts} {HOSTNAME} sshd[{pid}]: "
            f"Accepted password for {user} from {ip} port {port} ssh2"
        )
        _write_syslog_line(
            f"{ts} {HOSTNAME} systemd[1]: "
            f"Started Session {random.randint(1, 999)} of user {user}."
        )
        time.sleep(0.3)


def simulate_brute_force_attack(attempts: int = 8) -> None:
    """
    Write repeated failed logins from a single attacker IP in quick
    succession, which should trigger FailedLoginDetector
    (default threshold: 5 attempts within 120 seconds).
    """
    attacker_ip = random.choice(ATTACKER_IPS)
    print(
        f"[demo] Simulating brute-force attack from {attacker_ip} "
        f"({attempts} failed attempts)..."
    )
    for i in range(attempts):
        ts = _syslog_timestamp()
        user = random.choice(USERNAMES)
        port = random.randint(40000, 60000)
        pid = random.randint(1000, 9999)

        _write_auth_line(
            f"{ts} {HOSTNAME} sshd[{pid}]: "
            f"Failed password for invalid user {user} from {attacker_ip} port {port} ssh2"
        )
        print(f"  -> attempt {i + 1}/{attempts} (user={user})")
        time.sleep(1)


def simulate_sudo_failure(count: int = 3) -> None:
    """Write sudo authentication failure events."""
    print(f"[demo] Simulating {count} sudo authentication failures...")
    for _ in range(count):
        ts = _syslog_timestamp()
        user = random.choice(["alice", "bob", "eve"])

        _write_auth_line(
            f"{ts} {HOSTNAME} sudo: pam_unix(sudo:auth): "
            f"authentication failure; logname= uid=1000 euid=0 "
            f"tty=/dev/pts/0 ruser= rhost= user={user}"
        )
        time.sleep(0.5)


def simulate_port_scan(
    port_count: int = PORT_SCAN_PORT_COUNT, hold_seconds: int = PORT_SCAN_HOLD_SECONDS
) -> None:
    """
    Open loopback connections to many distinct local ports and hold them
    open, so PortScanDetector's periodic psutil.net_connections() poll is
    guaranteed to observe all of them at once (see module docstring for why
    a fast scan like `nmap` is not reliable for this).
    """
    print(
        f"[demo] Simulating a port scan: connecting to {port_count} distinct "
        f"loopback ports and holding them open for {hold_seconds}s..."
    )
    servers: list[socket.socket] = []
    clients: list[socket.socket] = []
    try:
        for _ in range(port_count):
            server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            server.bind(("127.0.0.1", 0))
            server.listen(1)
            servers.append(server)

        for server in servers:
            port = server.getsockname()[1]
            client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client.connect(("127.0.0.1", port))
            clients.append(client)

        print(
            f"[demo] Connected to {len(clients)} ports. Holding open for "
            f"{hold_seconds}s so the next detection cycle catches all of them..."
        )
        time.sleep(hold_seconds)
    finally:
        for sock in clients + servers:
            try:
                sock.close()
            except OSError:
                pass


def main() -> None:
    """Run the complete demo scenario."""
    _reset_sample_logs()

    print("=" * 60)
    print(" Mini SOC Demo Data Generator")
    print("=" * 60)
    print()
    print(f"  Auth log:  {AUTH_LOG}")
    print(f"  Syslog:    {SYSLOG}")
    print()
    print(
        "  Make sure `python app.py` is already running in another "
        "terminal — this script only writes log files and opens "
        "sockets; the running app's collector/detector threads do the "
        "actual collection and detection."
    )
    print()

    # Phase 1: Normal traffic
    simulate_normal_traffic(count=5)
    time.sleep(2)

    # Phase 2: Brute-force attack
    simulate_brute_force_attack(attempts=8)
    time.sleep(1)

    # Phase 3: Sudo failures
    simulate_sudo_failure(count=3)

    # Phase 4: Port scan
    print()
    simulate_port_scan()

    print()
    print("[demo] Done! Synthetic events have been written to sample_logs/.")
    print("[demo] Within one collector cycle (~10s) and one detection cycle")
    print("       (~15s), the dashboard should show:")
    print("         - Recent Logs: normal logins + failed logins")
    print("         - Alerts: failed_login (brute-force) + port_scan")
    print()
    print("[demo] Additional tip: run `ncat -l 4444` in another terminal to")
    print("       trigger suspicious process detection.")


if __name__ == "__main__":
    main()
