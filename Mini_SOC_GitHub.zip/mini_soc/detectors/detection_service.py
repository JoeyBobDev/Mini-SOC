"""
detectors/detection_service.py
================================
Orchestrates all three detectors (failed login, port scan, suspicious
process) on a shared polling loop, running independently of the log
collector.

This is what ``app.py`` starts in its own background thread.
"""

from __future__ import annotations

import time
from typing import Optional

from config import Config
from database.db_manager import DatabaseManager
from detectors.failed_login_detector import FailedLoginDetector
from detectors.port_scan_detector import PortScanDetector
from detectors.process_detector import ProcessDetector
from utils.logger import get_logger

logger = get_logger(__name__)


class DetectionService:
    """Runs the failed-login, port-scan, and process detectors on a timer."""

    def __init__(
        self,
        db_manager: DatabaseManager,
        polling_interval: Optional[int] = None,
    ) -> None:
        self.db_manager = db_manager
        self.polling_interval = polling_interval or Config.PROCESS_SCAN_INTERVAL_SECONDS
        self.failed_login_detector = FailedLoginDetector(db_manager)
        self.port_scan_detector = PortScanDetector(db_manager)
        self.process_detector = ProcessDetector(db_manager)
        self._running = False

    def run_once(self) -> dict[str, int]:
        """
        Run a single pass of all three detectors.

        Returns:
            A dict mapping detector name to number of alerts it raised.
        """
        results: dict[str, int] = {}

        try:
            results["failed_login"] = self.failed_login_detector.scan()
        except Exception:  # pylint: disable=broad-except
            logger.exception("FailedLoginDetector.scan() raised an error.")
            results["failed_login"] = 0

        try:
            results["port_scan"] = self.port_scan_detector.scan()
        except Exception:  # pylint: disable=broad-except
            logger.exception("PortScanDetector.scan() raised an error.")
            results["port_scan"] = 0

        try:
            results["suspicious_process"] = self.process_detector.scan()
        except Exception:  # pylint: disable=broad-except
            logger.exception("ProcessDetector.scan() raised an error.")
            results["suspicious_process"] = 0

        total = sum(results.values())
        if total:
            logger.info("Detection pass complete: %s", results)

        return results

    def run_forever(self) -> None:
        """Run the detection loop until ``stop()`` is called."""
        self._running = True
        logger.info(
            "Detection service started (interval=%ss).", self.polling_interval
        )
        while self._running:
            self.run_once()
            time.sleep(self.polling_interval)

    def stop(self) -> None:
        """Signal the detection loop to stop after its current iteration."""
        self._running = False
        logger.info("Detection service stop requested.")
