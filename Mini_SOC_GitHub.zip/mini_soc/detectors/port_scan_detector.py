"""
detectors/port_scan_detector.py
=================================
Detects basic port-scanning behaviour: a single remote IP address
connecting to many distinct local ports in a short time window.

Data source: ``psutil.net_connections()``, which exposes the local
machine's current network connection table (works cross-platform on
Linux/Windows/macOS without requiring raw packet capture or root
privileges for most connection states).

Rule: if a single remote IP touches
``Config.PORT_SCAN_PORT_THRESHOLD`` or more distinct local ports
within a rolling ``Config.PORT_SCAN_WINDOW_SECONDS`` window, an alert
is raised.
"""

from __future__ import annotations

import datetime as _dt
import json
import socket
from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Optional

import psutil

from config import Config
from database.db_manager import DatabaseManager
from utils.json_normalizer import now_iso
from utils.logger import get_logger

logger = get_logger(__name__)


@dataclass
class _ConnectionSighting:
    """A single observed (remote_ip -> local_port) connection at a point in time."""

    seen_at: _dt.datetime
    remote_ip: str
    local_port: int


class PortScanDetector:
    """Detects many-distinct-ports-in-a-short-time (port scan) behaviour."""

    ALERT_TYPE = "port_scan"

    def __init__(
        self,
        db_manager: DatabaseManager,
        port_threshold: Optional[int] = None,
        window_seconds: Optional[int] = None,
    ) -> None:
        self.db_manager = db_manager
        self.port_threshold = port_threshold or Config.PORT_SCAN_PORT_THRESHOLD
        self.window_seconds = window_seconds or Config.PORT_SCAN_WINDOW_SECONDS
        self.hostname = socket.gethostname()
        # Rolling in-memory buffer of recent connection sightings.
        self._sightings: deque[_ConnectionSighting] = deque()

    def _prune_old_sightings(self, now: _dt.datetime) -> None:
        """Drop sightings older than the detection window from the buffer."""
        cutoff = now - _dt.timedelta(seconds=self.window_seconds)
        while self._sightings and self._sightings[0].seen_at < cutoff:
            self._sightings.popleft()

    def _capture_current_connections(self, now: _dt.datetime) -> None:
        """Read the OS connection table and append new sightings to the buffer."""
        try:
            connections = psutil.net_connections(kind="inet")
        except (psutil.AccessDenied, PermissionError):
            logger.warning(
                "Insufficient permissions to read network connections; "
                "port scan detection may be limited. Try running with "
                "elevated privileges."
            )
            return
        except Exception:  # pylint: disable=broad-except
            logger.exception("Unexpected error reading network connections.")
            return

        for conn in connections:
            if not conn.raddr or not conn.laddr:
                continue
            remote_ip = conn.raddr.ip
            local_port = conn.laddr.port
            if not remote_ip:
                continue
            # Note: loopback (127.0.0.1/::1) connections are intentionally
            # NOT excluded, so the detector can be exercised locally with
            # tools like `nmap -p 1-100 localhost` for demo/testing
            # purposes. In a hardened deployment you may want to filter
            # loopback traffic out to reduce noise.
            self._sightings.append(
                _ConnectionSighting(seen_at=now, remote_ip=remote_ip, local_port=local_port)
            )

    def scan(self) -> int:
        """
        Capture current connections, update the rolling window, and raise
        alerts for any remote IP exceeding the distinct-port threshold.

        Returns:
            The number of new alerts raised during this scan.
        """
        now = _dt.datetime.now(_dt.timezone.utc)
        self._capture_current_connections(now)
        self._prune_old_sightings(now)

        ports_by_ip: dict[str, set[int]] = defaultdict(set)
        for sighting in self._sightings:
            ports_by_ip[sighting.remote_ip].add(sighting.local_port)

        since_iso = (now - _dt.timedelta(seconds=self.window_seconds)).isoformat()
        alerts_raised = 0

        for remote_ip, ports in ports_by_ip.items():
            if len(ports) < self.port_threshold:
                continue

            if self.db_manager.alert_exists_recently(self.ALERT_TYPE, remote_ip, since_iso):
                continue

            description = (
                f"Possible port scan detected: {remote_ip} connected to "
                f"{len(ports)} distinct ports within {self.window_seconds}s "
                f"(threshold: {self.port_threshold})."
            )

            alert_id = self.db_manager.insert_alert(
                timestamp=now_iso(),
                alert_type=self.ALERT_TYPE,
                description=description,
                severity="high",
                source_ip=remote_ip,
                username=None,
                hostname=self.hostname,
                details={
                    "distinct_ports": sorted(ports),
                    "port_count": len(ports),
                    "window_seconds": self.window_seconds,
                },
            )

            # Also record in the dedicated port_scans table
            self.db_manager.insert_port_scan(
                timestamp=now_iso(),
                source_ip=remote_ip,
                ports_scanned=json.dumps(sorted(ports)),
                port_count=len(ports),
                hostname=self.hostname,
                alert_id=alert_id,
            )

            alerts_raised += 1
            logger.warning("ALERT [port_scan]: %s", description)

        return alerts_raised
