"""Detectors package: failed-login, port-scan, and process detection logic."""
