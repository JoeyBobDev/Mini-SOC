"""
detectors/failed_login_detector.py
====================================
Detects repeated failed login (brute-force) attempts.

Rule: if the same source (identified primarily by source_ip, falling
back to username when no IP is available) accumulates
``Config.FAILED_LOGIN_THRESHOLD`` or more ``failed_login`` events
within a rolling ``Config.FAILED_LOGIN_WINDOW_SECONDS`` window, an
alert is raised.

Duplicate suppression: once an alert has been raised for a given
source within the current window, the detector will not raise another
one until the window has fully elapsed, preventing alert spam while
the attack is ongoing.
"""

from __future__ import annotations

import datetime as _dt
from collections import defaultdict
from typing import Optional

from config import Config
from database.db_manager import DatabaseManager
from utils.json_normalizer import now_iso
from utils.logger import get_logger

logger = get_logger(__name__)


class FailedLoginDetector:
    """Detects brute-force / repeated failed login attempts from log data."""

    ALERT_TYPE = "failed_login"

    def __init__(
        self,
        db_manager: DatabaseManager,
        threshold: Optional[int] = None,
        window_seconds: Optional[int] = None,
    ) -> None:
        self.db_manager = db_manager
        self.threshold = threshold or Config.FAILED_LOGIN_THRESHOLD
        self.window_seconds = window_seconds or Config.FAILED_LOGIN_WINDOW_SECONDS

    def _window_start_iso(self) -> str:
        """Return the ISO timestamp marking the start of the detection window."""
        cutoff = _dt.datetime.now(_dt.timezone.utc) - _dt.timedelta(
            seconds=self.window_seconds
        )
        return cutoff.isoformat()

    def scan(self) -> int:
        """
        Scan recent failed_login logs and raise alerts for sources that
        exceed the threshold within the configured time window.

        Returns:
            The number of new alerts raised during this scan.
        """
        since_iso = self._window_start_iso()
        recent_failures = self.db_manager.get_logs_by_event_type(
            "failed_login", since_iso=since_iso
        )

        if not recent_failures:
            return 0

        # Group failures by source identity: prefer source_ip, else username.
        grouped: dict[str, list[dict]] = defaultdict(list)
        for entry in recent_failures:
            key = entry.get("source_ip") or entry.get("username") or "unknown"
            grouped[key].append(entry)

        alerts_raised = 0
        for source_key, entries in grouped.items():
            if len(entries) < self.threshold:
                continue

            source_ip = entries[0].get("source_ip")
            already_alerted = self.db_manager.alert_exists_recently(
                self.ALERT_TYPE, source_ip, since_iso
            )
            if already_alerted:
                continue

            usernames = sorted({e.get("username") for e in entries if e.get("username")})
            hostname = entries[-1].get("hostname")

            description = (
                f"{len(entries)} failed login attempts detected from "
                f"'{source_key}' within {self.window_seconds}s "
                f"(threshold: {self.threshold})."
            )

            self.db_manager.insert_alert(
                timestamp=now_iso(),
                alert_type=self.ALERT_TYPE,
                description=description,
                severity="high" if len(entries) >= self.threshold * 2 else "medium",
                source_ip=source_ip,
                username=usernames[0] if len(usernames) == 1 else None,
                hostname=hostname,
                details={
                    "attempt_count": len(entries),
                    "usernames_targeted": usernames,
                    "window_seconds": self.window_seconds,
                },
            )
            alerts_raised += 1
            logger.warning("ALERT [failed_login]: %s", description)

        return alerts_raised
