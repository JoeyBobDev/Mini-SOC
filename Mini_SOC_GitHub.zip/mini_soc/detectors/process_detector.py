"""
detectors/process_detector.py
===============================
Monitors currently running processes and flags any that match a
configurable blacklist of suspicious tool names (e.g. mimikatz, nc.exe,
ncat, netcat, psexec).

Matching checks both the process **name** (exact, case-insensitive) and
the **command line** (word-boundary-aware, case-insensitive) to reduce
false positives while still catching e.g. ``/usr/bin/ncat`` or
``powershell.exe -enc ... mimikatz ...``.

Each newly-flagged process is stored in the ``processes`` table and
raises a corresponding alert. Already-flagged PIDs are not re-alerted
on every poll cycle; a process is re-evaluated only once its PID
disappears and a new PID reuses suspicious behaviour.
"""

from __future__ import annotations

import re
import socket
from typing import Optional

import psutil

from config import Config
from database.db_manager import DatabaseManager
from utils.json_normalizer import now_iso
from utils.logger import get_logger

logger = get_logger(__name__)

# These process names are always benign and should be excluded from
# blacklist matching to prevent false positives on short tokens like "nc".
_BENIGN_PROCESS_NAMES = frozenset({
    "chrome", "chromium", "firefox", "code", "node",
    "postgres", "postgresql", "systemd", "systemd-timesyncd",
    "systemd-resolved", "systemd-logind", "systemd-journald",
    "gnome-shell", "gnome-terminal", "gnome-session",
    "at-spi-bus-launcher", "dbus-daemon", "dconf-service",
    "journalctl", "antigravity", "python", "python3",
    "pip", "pipx", "pytest", "bash", "zsh", "sh", "fish",
    "sshd", "ssh-agent", "init", "kworker", "ksoftirqd",
    "containerd", "dockerd", "snapd", "pulseaudio",
    "pipewire", "gdm", "lightdm", "xfce4-session",
})


class ProcessDetector:
    """Scans running processes against a configurable suspicious-name blacklist."""

    ALERT_TYPE = "suspicious_process"

    def __init__(
        self,
        db_manager: DatabaseManager,
        blacklist: Optional[list[str]] = None,
    ) -> None:
        self.db_manager = db_manager
        self.blacklist: list[str] = [
            entry.lower() for entry in (blacklist or Config.SUSPICIOUS_PROCESS_BLACKLIST)
        ]
        self.hostname = socket.gethostname()
        # PIDs already flagged this "run" so we don't spam duplicate alerts.
        self._flagged_pids: set[int] = set()

        # Pre-compile regex patterns for word-boundary matching
        self._patterns: dict[str, re.Pattern] = {}
        for token in self.blacklist:
            # Use word boundaries for tokens that are too short or too common
            # to safely substring-match. For longer/specific tokens, still
            # use word boundary matching for precision.
            escaped = re.escape(token)
            self._patterns[token] = re.compile(
                rf"(?:^|[\s/\\])({escaped})(?:[\s/\\.]|$)",
                re.IGNORECASE,
            )

    def _match_blacklist(self, name: str, cmdline: str) -> Optional[str]:
        """
        Return the matched blacklist token if name/cmdline is suspicious, else None.

        Matching strategy:
        1. Check if the process name (case-insensitive) exactly matches a blacklist token
           or starts with one (e.g. "mimikatz.exe" matches "mimikatz").
        2. Check command line args with word-boundary regex matching.
        """
        name_lower = name.lower().strip()

        # Skip known-benign process names
        if name_lower in _BENIGN_PROCESS_NAMES:
            return None

        for token in self.blacklist:
            # Exact name match or name starts with the token (for .exe variants)
            if name_lower == token or name_lower == f"{token}.exe":
                return token

            # Check if the process name, stripped of extension, matches
            base_name = name_lower.rsplit(".", 1)[0] if "." in name_lower else name_lower
            if base_name == token:
                return token

        # Check command line with regex for word-boundary matching
        if cmdline:
            for token, pattern in self._patterns.items():
                if pattern.search(cmdline):
                    return token

        return None

    def scan(self) -> int:
        """
        Scan all running processes for blacklist matches.

        Returns:
            The number of newly flagged suspicious processes (and alerts) found.
        """
        alerts_raised = 0
        active_pids: set[int] = set()

        for proc in psutil.process_iter(["pid", "name", "username", "cmdline"]):
            try:
                info = proc.info
                pid = info.get("pid")
                name = info.get("name") or ""
                cmdline_list = info.get("cmdline") or []
                cmdline = " ".join(cmdline_list)
                username = info.get("username")
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue

            if pid is None:
                continue
            active_pids.add(pid)

            matched_rule = self._match_blacklist(name, cmdline)
            if not matched_rule:
                continue

            if pid in self._flagged_pids:
                continue  # already alerted for this PID

            self._flagged_pids.add(pid)

            self.db_manager.insert_process(
                timestamp=now_iso(),
                hostname=self.hostname,
                pid=pid,
                process_name=name,
                username=username,
                command_line=cmdline,
                is_suspicious=True,
                matched_rule=matched_rule,
            )

            description = (
                f"Suspicious process detected: '{name}' (PID {pid}) matched "
                f"blacklist rule '{matched_rule}'."
            )
            self.db_manager.insert_alert(
                timestamp=now_iso(),
                alert_type=self.ALERT_TYPE,
                description=description,
                severity="critical",
                source_ip=None,
                username=username,
                hostname=self.hostname,
                details={
                    "pid": pid,
                    "process_name": name,
                    "command_line": cmdline,
                    "matched_rule": matched_rule,
                },
            )
            alerts_raised += 1
            logger.warning("ALERT [suspicious_process]: %s", description)

        # Forget PIDs that are no longer running so a future PID reuse
        # (or a new suspicious process with the same PID number) is re-evaluated.
        self._flagged_pids &= active_pids

        return alerts_raised
